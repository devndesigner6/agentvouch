---
name: agentvouch-design
description: Use this skill to generate well-branded interfaces and assets for AgentVouch (agentvouch.xyz — on-chain trust layer and skills marketplace for AI agents), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Key facts: the brand is a warm coral/lobster accent (#d95a2b / #fd522e) on cool gray neutrals; Inconsolata mono is the load-bearing UI type; Crimson Text serif carries titles and stats; one true 6px radius; 1px hairline borders; the signature hover is a coral lift (translateY(-2px) + coral border + warm coral shadow). Trust renders as a 4-step verdict scale (emerald Trusted / amber Review / red Flagged / gray Unverified). Tokens live in `tokens/*.css` behind the single entry `styles.css`; reusable React components in `components/**`; a full interactive recreation of agentvouch.xyz in `ui_kits/web/`; the Coral Terminal slide theme in `slides/`; logos and lobster illustrations in `assets/`.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
