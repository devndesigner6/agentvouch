/* @ds-bundle: {"format":3,"namespace":"AgentVouchDesignSystem_7f5188","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"SkillCard","sourcePath":"components/data/SkillCard.jsx"},{"name":"StatBlock","sourcePath":"components/data/StatBlock.jsx"},{"name":"TrustBadge","sourcePath":"components/feedback/TrustBadge.jsx"},{"name":"VerdictChip","sourcePath":"components/feedback/VerdictChip.jsx"},{"name":"VerdictDot","sourcePath":"components/feedback/VerdictChip.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"AgentSigil","sourcePath":"components/identity/AgentSigil.jsx"},{"name":"SkillIcon","sourcePath":"components/identity/SkillIcon.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"1de8fad9da47","components/core/Button.jsx":"46d2a1df3248","components/core/Eyebrow.jsx":"23609ca61544","components/core/Tag.jsx":"17abc606a924","components/data/Card.jsx":"63e7b0569181","components/data/SkillCard.jsx":"fd99f172a5b3","components/data/StatBlock.jsx":"8a1dce420b3d","components/feedback/TrustBadge.jsx":"3f98881bb3d6","components/feedback/VerdictChip.jsx":"5ac37411fe07","components/forms/Input.jsx":"f8754eaa78cd","components/forms/Select.jsx":"1382c977cd8c","components/identity/AgentSigil.jsx":"711182e7d5dc","components/identity/SkillIcon.jsx":"5abd1e73f088","ui_kits/web/chrome.jsx":"36dd0a004982","ui_kits/web/data.js":"ac4fe79cdbe8","ui_kits/web/detail.jsx":"96de0f52225e","ui_kits/web/landing.jsx":"f849fb837337","ui_kits/web/marketplace.jsx":"815143d4ebb1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AgentVouchDesignSystem_7f5188 = window.AgentVouchDesignSystem_7f5188 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — a small status pill. Uppercase mono, tracked. Used for network
 * status ("Devnet"), tiers, and state flags. Tones map to the brand's
 * accent + verdict palette.
 */
function Badge({
  children,
  tone = "neutral",
  icon = null,
  style = {},
  ...rest
}) {
  const tones = {
    neutral: {
      bg: "var(--gray-100)",
      fg: "var(--gray-600)",
      bd: "var(--border)"
    },
    coral: {
      bg: "var(--coral-soft)",
      fg: "var(--accent-on-soft)",
      bd: "var(--coral-border)"
    },
    sea: {
      bg: "var(--sea-soft)",
      fg: "var(--sea-strong)",
      bd: "var(--sea-border)"
    },
    allow: {
      bg: "var(--verdict-allow-soft)",
      fg: "var(--verdict-allow)",
      bd: "var(--verdict-allow-border)"
    },
    review: {
      bg: "var(--verdict-review-soft)",
      fg: "var(--verdict-review)",
      bd: "var(--verdict-review-border)"
    },
    avoid: {
      bg: "var(--verdict-avoid-soft)",
      fg: "var(--verdict-avoid)",
      bd: "var(--verdict-avoid-border)"
    },
    green: {
      bg: "rgba(5,150,105,0.1)",
      fg: "var(--verdict-allow)",
      bd: "var(--verdict-allow-border)"
    }
  };
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "5px",
      padding: "2px 8px",
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.bd}`,
      borderRadius: "var(--radius-full)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      lineHeight: 1.4,
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AgentVouch Button — the primary interactive control.
 *
 * Mono type, sharp 6px corners, no uppercase by default. The primary
 * variant is solid ember coral; secondary is a soft sea-teal capsule with
 * a hairline border; ghost is text-only; danger reuses ember for
 * destructive/slashing actions. Hover deepens the fill (primary) or the
 * soft wash (secondary); disabled drops to a flat gray.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "5px 10px",
      fontSize: "var(--text-xs)",
      gap: "5px"
    },
    md: {
      padding: "7px 14px",
      fontSize: "var(--text-sm)",
      gap: "8px"
    },
    lg: {
      padding: "10px 20px",
      fontSize: "var(--text-base)",
      gap: "8px"
    }
  };
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "var(--font-mono)",
    fontWeight: 400,
    lineHeight: 1,
    borderRadius: "var(--radius)",
    border: "1px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "background var(--duration) var(--ease), border-color var(--duration) var(--ease), color var(--duration) var(--ease)",
    whiteSpace: "nowrap",
    textDecoration: "none",
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: "var(--accent-strong)",
      color: "var(--text-on-accent)"
    },
    secondary: {
      background: "var(--sea-soft)",
      color: "var(--sea-strong)",
      borderColor: "var(--sea-border)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-muted)"
    },
    danger: {
      background: "var(--ember)",
      color: "#fff"
    }
  };
  const disabledStyle = disabled ? {
    background: "var(--gray-300)",
    color: "var(--gray-500)",
    borderColor: "transparent"
  } : {};
  const hover = {
    primary: {
      background: "var(--accent)"
    },
    secondary: {
      background: "var(--sea-soft-hover)"
    },
    ghost: {
      color: "var(--accent)"
    },
    danger: {
      background: "var(--coral-muted)"
    }
  };
  const handleEnter = e => {
    if (disabled) return;
    Object.assign(e.currentTarget.style, hover[variant]);
  };
  const handleLeave = e => {
    if (disabled) return;
    Object.assign(e.currentTarget.style, {
      background: variants[variant].background,
      color: variants[variant].color
    });
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      ...base,
      ...variants[variant],
      ...disabledStyle,
      ...style
    },
    disabled: as === "button" ? disabled : undefined,
    onMouseEnter: handleEnter,
    onMouseLeave: handleLeave
  }, rest), iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, iconLeft), children, iconRight && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, iconRight));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Eyebrow — the all-caps, tracked monospace label that sits above titles
 * and marks sections ("THE PROBLEM", "AGENT REPUTATION ORACLE"). A
 * load-bearing brand motif. Optionally rendered as a coral-soft chip.
 */
function Eyebrow({
  children,
  chip = false,
  color = "var(--accent)",
  style = {},
  ...rest
}) {
  const base = {
    fontFamily: "var(--font-mono)",
    fontSize: "var(--text-2xs)",
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-wider)",
    color,
    lineHeight: 1.4,
    display: "inline-block"
  };
  const chipStyle = chip ? {
    padding: "4px 12px",
    background: "var(--coral-soft)",
    border: "1px solid var(--coral-border)",
    borderRadius: "var(--radius-full)"
  } : {};
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      ...chipStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tag — a lowercase capability tag for skills. Coral-soft capsule with a
 * coral hairline border. Always lowercase; reads as a quiet metadata token,
 * not a loud chip. Optionally clickable (filter by tag).
 */
function Tag({
  children,
  onClick = null,
  style = {},
  ...rest
}) {
  const interactive = typeof onClick === "function";
  return /*#__PURE__*/React.createElement("span", _extends({
    role: interactive ? "button" : undefined,
    tabIndex: interactive ? 0 : undefined,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "2px 8px",
      background: "var(--coral-soft)",
      color: "var(--accent-on-soft)",
      border: "1px solid var(--coral-border)",
      borderRadius: "var(--radius-full)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      textTransform: "lowercase",
      letterSpacing: "var(--tracking-wide)",
      lineHeight: 1.5,
      cursor: interactive ? "pointer" : "default",
      transition: "border-color var(--duration) var(--ease), background var(--duration) var(--ease)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the base surface. White (or ink) fill, 1px hairline border, sharp
 * 6px corners, subtle shadow. Set `interactive` for the signature coral hover
 * lift (raise + coral border + warm shadow). Optional left `rail` accent.
 */
function Card({
  children,
  interactive = false,
  rail = null,
  padding = "16px",
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--surface)",
      border: `1px solid ${hover ? "var(--accent-border)" : "var(--border)"}`,
      borderRadius: "var(--radius)",
      boxShadow: hover ? "var(--shadow-coral)" : "var(--shadow-sm)",
      transform: hover ? "translateY(-2px)" : "translateY(0)",
      transition: "transform var(--duration) var(--ease), border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
      padding,
      ...style
    }
  }, rest), rail && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: "absolute",
      insetBlock: 0,
      left: 0,
      width: "var(--rail-width)",
      background: rail === true ? "var(--accent)" : rail,
      opacity: interactive ? hover ? 1 : 0 : 1,
      transition: "opacity var(--duration) var(--ease)"
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/data/StatBlock.jsx
try { (() => {
/**
 * StatBlock — a big coral number with a small tracked mono label beneath.
 * The brand's signature metric callout (landing stats, dispute counts,
 * staked totals). Serif display numerals, coral by default.
 */
function StatBlock({
  value,
  label,
  accent = true,
  align = "center",
  size = "lg",
  style = {}
}) {
  const sizes = {
    md: "var(--text-2xl)",
    lg: "var(--text-3xl)",
    xl: "var(--text-4xl)"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: align,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: sizes[size] || sizes.lg,
      lineHeight: 1,
      color: accent ? "var(--accent)" : "var(--foreground)",
      marginBottom: "6px"
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      fontWeight: 500,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "var(--text-faint)"
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/feedback/TrustBadge.jsx
try { (() => {
/**
 * TrustBadge — the at-a-glance on-chain trust readout for an author. Renders
 * the five core trust signals as a row of compact stat cells: reputation,
 * vouches received, USDC backing from others, the author's own self-bond,
 * and report/dispute status. `compact` renders a single inline strip instead.
 *
 * Values are display-ready strings/numbers (format USDC upstream).
 */
function TrustBadge({
  reputation = 0,
  vouches = 0,
  backing = "0",
  selfBond = "0",
  reportStatus = {
    label: "Clean",
    tone: "allow"
  },
  compact = false,
  style = {}
}) {
  const toneColor = {
    allow: "var(--verdict-allow)",
    review: "var(--verdict-review)",
    avoid: "var(--verdict-avoid)",
    neutral: "var(--text-muted)"
  }[reportStatus.tone || "allow"];
  if (compact) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        alignItems: "center",
        gap: "12px",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-xs)",
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        color: "var(--verdict-allow)"
      }
    }, /*#__PURE__*/React.createElement(Shield, null), " ", reputation), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        color: "var(--accent)"
      }
    }, /*#__PURE__*/React.createElement(Users, null), " ", vouches), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-muted)"
      }
    }, "Backing ", backing, " USDC"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-muted)"
      }
    }, "Self ", selfBond, " USDC"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: toneColor
      }
    }, "\u26A0 ", reportStatus.label));
  }
  const cells = [{
    icon: /*#__PURE__*/React.createElement(Shield, null),
    value: reputation,
    label: "Reputation",
    color: "var(--verdict-allow)"
  }, {
    icon: /*#__PURE__*/React.createElement(Users, null),
    value: vouches,
    label: "Vouches",
    color: "var(--accent)"
  }, {
    icon: /*#__PURE__*/React.createElement(Coins, null),
    value: backing,
    label: "Backing",
    color: "var(--accent)"
  }, {
    icon: /*#__PURE__*/React.createElement(User, null),
    value: selfBond,
    label: "Self Stake",
    color: "var(--sea)"
  }, {
    icon: /*#__PURE__*/React.createElement(Warn, null),
    value: reportStatus.label,
    label: "Reports",
    color: toneColor,
    small: true
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(5, minmax(0,1fr))",
      gap: "12px",
      ...style
    }
  }, cells.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.label,
    style: {
      border: "1px solid var(--border)",
      background: "var(--surface-sunken)",
      borderRadius: "var(--radius)",
      padding: "12px 8px",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: c.color,
      marginBottom: "4px",
      display: "flex",
      justifyContent: "center"
    }
  }, c.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: c.small ? "var(--text-sm)" : "var(--text-lg)",
      fontWeight: 700,
      color: "var(--foreground)"
    }
  }, c.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)",
      marginTop: "2px"
    }
  }, c.label))));
}

/* Minimal inline Feather-style glyphs (stroke 2, 16px) to keep the component
   dependency-free. In product, swap for react-icons/fi equivalents. */
const ico = {
  width: 16,
  height: 16,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const Shield = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
}));
const Users = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "7",
  r: "4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M23 21v-2a4 4 0 0 0-3-3.87"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 3.13a4 4 0 0 1 0 7.75"
}));
const Coins = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("circle", {
  cx: "8",
  cy: "8",
  r: "6"
}), /*#__PURE__*/React.createElement("path", {
  d: "M18.09 10.37A6 6 0 1 1 10.34 18"
}), /*#__PURE__*/React.createElement("path", {
  d: "M7 6h1v4"
}));
const User = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "7",
  r: "4"
}));
const Warn = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "9",
  x2: "12",
  y2: "13"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17"
}));
Object.assign(__ds_scope, { TrustBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/TrustBadge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/VerdictChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * VerdictChip — the trust verdict pill that summarizes an author's on-chain
 * standing at a glance. Four states map to the verdict scale:
 *   allow   → Trusted   (emerald)
 *   review  → Review    (amber)
 *   avoid   → Flagged   (red)
 *   unknown → Unverified (gray)
 * Uppercase mono, fully-rounded, hairline border on a soft tinted fill.
 */
const META = {
  allow: {
    label: "Trusted",
    glyph: "✓",
    fg: "var(--verdict-allow)",
    bg: "var(--verdict-allow-soft)",
    bd: "var(--verdict-allow-border)"
  },
  review: {
    label: "Review",
    glyph: "!",
    fg: "var(--verdict-review)",
    bg: "var(--verdict-review-soft)",
    bd: "var(--verdict-review-border)"
  },
  avoid: {
    label: "Flagged",
    glyph: "!",
    fg: "var(--verdict-avoid)",
    bg: "var(--verdict-avoid-soft)",
    bd: "var(--verdict-avoid-border)"
  },
  unknown: {
    label: "Unverified",
    glyph: "◇",
    fg: "var(--verdict-unknown)",
    bg: "var(--verdict-unknown-soft)",
    bd: "var(--verdict-unknown-border)"
  }
};
function VerdictChip({
  verdict = "unknown",
  label = null,
  icon = null,
  style = {},
  ...rest
}) {
  const m = META[verdict] || META.unknown;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "5px",
      padding: "2px 9px",
      background: m.bg,
      color: m.fg,
      border: `1px solid ${m.bd}`,
      borderRadius: "var(--radius-full)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      lineHeight: 1.4,
      whiteSpace: "nowrap",
      ...style
    },
    title: m.label
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      fontSize: "0.9em"
    }
  }, icon || m.glyph), label || m.label);
}

/**
 * VerdictDot — the tiny ring-bordered status dot used as a corner badge on
 * a SkillIcon. Same four states as VerdictChip.
 */
function VerdictDot({
  verdict = "unknown",
  size = 16
}) {
  const m = META[verdict] || META.unknown;
  const solid = {
    allow: "var(--verdict-allow)",
    review: "var(--verdict-review)",
    avoid: "var(--verdict-avoid)",
    unknown: "var(--verdict-unknown)"
  }[verdict];
  return /*#__PURE__*/React.createElement("span", {
    title: m.label,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: size,
      height: size,
      borderRadius: "var(--radius-full)",
      background: solid,
      color: "#fff",
      border: "2px solid var(--surface)",
      fontSize: size * 0.55,
      fontWeight: 700,
      lineHeight: 1
    }
  }, m.glyph);
}
Object.assign(__ds_scope, { VerdictChip, VerdictDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/VerdictChip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — single-line text field. Mono type, hairline border, sharp corners,
 * coral focus ring. Supports an optional leading icon and a monospace prefix
 * (e.g. a "$" or "@"). Set `invalid` for the error state.
 */
function Input({
  icon = null,
  prefix = null,
  invalid = false,
  style = {},
  wrapperStyle = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const border = invalid ? "var(--verdict-avoid)" : focus ? "var(--accent)" : "var(--border-strong)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      background: "var(--surface)",
      border: `1px solid ${border}`,
      borderRadius: "var(--radius)",
      padding: "0 12px",
      height: "var(--control-height)",
      boxShadow: focus ? "var(--ring)" : "none",
      transition: "border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
      ...wrapperStyle
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--text-faint)"
    }
  }, icon), prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-faint)"
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-body)",
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select — a styled native dropdown. Matches Input's frame (mono, hairline
 * border, sharp corners, coral focus) with a custom chevron.
 */
function Select({
  options = [],
  invalid = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const border = invalid ? "var(--verdict-avoid)" : focus ? "var(--accent)" : "var(--border-strong)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "inline-flex",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      width: "100%",
      height: "var(--control-height)",
      padding: "0 32px 0 12px",
      background: "var(--surface)",
      border: `1px solid ${border}`,
      borderRadius: "var(--radius)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-body)",
      outline: "none",
      boxShadow: focus ? "var(--ring)" : "none",
      cursor: "pointer",
      transition: "border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
      ...style
    }
  }, rest), options.map(o => {
    const value = typeof o === "string" ? o : o.value;
    const label = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, label);
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: "absolute",
      right: 12,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--text-faint)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/identity/AgentSigil.jsx
try { (() => {
/**
 * Coral Sigil — a deterministic, SSR-safe identity avatar generated purely
 * from a seed string (an agent / author wallet address). Same seed → the
 * exact same seal, every render. A seeded coral gradient field overlaid
 * with 3–4 bold geometric forms and an occasional sealing ring.
 *
 * The address is destiny: identity is computed, not stored. Ported verbatim
 * from the production app (web/components/AgentSigil.tsx).
 */

const PALETTE = ["#F28A61",
// coral
"#FD522E",
// ember
"#F59E0B",
// amber
"#D95A2B",
// lobster
"#FDBA8C",
// light coral
"#7C2D12",
// deep
"#5F8F9B",
// sea
"#4E7782" // sea-strong
];
function xmur3(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i += 1) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = h << 13 | h >>> 19;
  }
  h = Math.imul(h ^ h >>> 16, 2246822507);
  h = Math.imul(h ^ h >>> 13, 3266489909);
  return (h ^= h >>> 16) >>> 0;
}
function mulberry32(a) {
  return () => {
    a |= 0;
    a = a + 0x6d2b79f5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function polygonPoints(cx, cy, r, sides, rotDeg) {
  const rot = rotDeg * Math.PI / 180;
  const pts = [];
  for (let i = 0; i < sides; i += 1) {
    const a = rot + i / sides * Math.PI * 2;
    pts.push(`${(cx + Math.cos(a) * r).toFixed(2)},${(cy + Math.sin(a) * r).toFixed(2)}`);
  }
  return pts.join(" ");
}
function AgentSigil({
  seed,
  size = 40,
  className,
  style = {}
}) {
  const seed32 = xmur3(seed || "agentvouch");
  const rng = mulberry32(seed32);
  const pick = arr => arr[Math.floor(rng() * arr.length)];
  const bgA = pick(PALETTE);
  let bgB = pick(PALETTE);
  if (bgB === bgA) bgB = PALETTE[(PALETTE.indexOf(bgA) + 3) % PALETTE.length];
  const angle = Math.floor(rng() * 4) * 45 + 45;
  const rad = angle * Math.PI / 180;
  const x2 = (0.5 + Math.cos(rad) * 0.5).toFixed(3);
  const y2 = (0.5 + Math.sin(rad) * 0.5).toFixed(3);
  const x1 = (0.5 - Math.cos(rad) * 0.5).toFixed(3);
  const y1 = (0.5 - Math.sin(rad) * 0.5).toFixed(3);
  const shapeCount = 3 + (rng() < 0.5 ? 0 : 1);
  const shapes = [];
  for (let i = 0; i < shapeCount; i += 1) {
    const cx = 22 + rng() * 56;
    const cy = 22 + rng() * 56;
    const r = 16 + rng() * 22;
    const fill = pick(PALETTE);
    const opacity = 0.55 + rng() * 0.4;
    const blend = i > 0 && rng() < 0.5 ? "overlay" : "normal";
    if (rng() < 0.62) {
      const sides = pick([3, 4, 6]);
      shapes.push({
        kind: "polygon",
        points: polygonPoints(cx, cy, r, sides, rng() * 360),
        fill,
        opacity,
        blend
      });
    } else {
      shapes.push({
        kind: "circle",
        cx,
        cy,
        r: r * 0.85,
        fill,
        opacity,
        blend
      });
    }
  }
  const hasRing = rng() < 0.5;
  const ringR = 30 + rng() * 12;
  const ringColor = pick(PALETTE);
  const gid = `avs-${seed32.toString(36)}`;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    width: size,
    height: size,
    className: className,
    preserveAspectRatio: "xMidYMid slice",
    style: {
      display: "block",
      ...style
    },
    "aria-hidden": true
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: gid,
    x1: x1,
    y1: y1,
    x2: x2,
    y2: y2
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: bgA
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: bgB
  }))), /*#__PURE__*/React.createElement("rect", {
    width: "100",
    height: "100",
    fill: `url(#${gid})`
  }), shapes.map((s, i) => s.kind === "polygon" ? /*#__PURE__*/React.createElement("polygon", {
    key: i,
    points: s.points,
    fill: s.fill,
    opacity: s.opacity,
    style: {
      mixBlendMode: s.blend
    }
  }) : /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: s.cx,
    cy: s.cy,
    r: s.r,
    fill: s.fill,
    opacity: s.opacity,
    style: {
      mixBlendMode: s.blend
    }
  })), hasRing && /*#__PURE__*/React.createElement("circle", {
    cx: "50",
    cy: "50",
    r: ringR,
    fill: "none",
    stroke: ringColor,
    strokeWidth: "2.5",
    opacity: "0.35"
  }));
}
Object.assign(__ds_scope, { AgentSigil });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/identity/AgentSigil.jsx", error: String((e && e.message) || e) }); }

// components/identity/SkillIcon.jsx
try { (() => {
/**
 * SkillIcon — the framed identity avatar used across the marketplace: a
 * generative Coral Sigil with a soft top highlight for depth, a 1px inset
 * ring (often a verdict color), and an optional corner badge (e.g. a
 * verdict status dot). Same author → same seal across all their skills.
 */
function SkillIcon({
  seed,
  size = 44,
  ringColor = "rgba(0,0,0,0.1)",
  badge = null,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      flexShrink: 0,
      width: size,
      height: size,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: "100%",
      height: "100%",
      overflow: "hidden",
      borderRadius: "var(--radius)",
      boxShadow: "var(--shadow-sm)",
      boxSizing: "border-box",
      border: `1px solid ${ringColor}`
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.AgentSigil, {
    seed: seed,
    size: size,
    style: {
      width: "100%",
      height: "100%"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      pointerEvents: "none",
      position: "absolute",
      inset: 0,
      background: "linear-gradient(to bottom, rgba(255,255,255,0.2), transparent)"
    }
  })), badge && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      bottom: -4,
      right: -4
    }
  }, badge));
}
Object.assign(__ds_scope, { SkillIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/identity/SkillIcon.jsx", error: String((e && e.message) || e) }); }

// components/data/SkillCard.jsx
try { (() => {
/**
 * SkillCard — the marketplace's core unit: a published skill with its author
 * identity, trust verdict, description, capability tags, and bottom stat row
 * (action pill · reputation · vouches · downloads). Composes SkillIcon,
 * VerdictChip/Dot, and Tag. Hover gives the signature coral lift + accent rail.
 */
const RING = {
  allow: "var(--verdict-allow)",
  review: "var(--verdict-review)",
  avoid: "var(--verdict-avoid)",
  unknown: "var(--verdict-unknown)"
};
function SkillCard({
  name,
  author,
  authorSeed,
  description,
  tags = [],
  verdict = "unknown",
  reputation = null,
  vouches = null,
  downloads = 0,
  version = null,
  price = null,
  // null/"Get" → free; string → USDC price
  installed = false,
  style = {}
}) {
  const [hover, setHover] = React.useState(false);
  const registered = verdict !== "unknown";
  const pillLabel = installed ? "Installed" : price ? `${price} USDC` : "Get";
  const pillStyle = installed ? {
    background: "var(--verdict-allow-soft)",
    color: "var(--verdict-allow)",
    border: "1px solid var(--verdict-allow-border)"
  } : {
    background: "var(--accent)",
    color: "#fff",
    border: "1px solid transparent"
  };
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      background: "var(--surface)",
      border: `1px solid ${hover ? "var(--accent-border)" : "var(--border)"}`,
      borderRadius: "var(--radius)",
      boxShadow: hover ? "var(--shadow-coral)" : "var(--shadow-sm)",
      transform: hover ? "translateY(-2px)" : "translateY(0)",
      transition: "transform var(--duration) var(--ease), border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: "absolute",
      insetBlock: 0,
      left: 0,
      width: "var(--rail-width)",
      background: RING[verdict],
      opacity: hover ? 1 : 0,
      transition: "opacity var(--duration) var(--ease)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "10px",
      padding: "16px",
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SkillIcon, {
    seed: authorSeed || author || name,
    size: 30,
    ringColor: RING[verdict],
    badge: /*#__PURE__*/React.createElement(__ds_scope.VerdictDot, {
      verdict: verdict,
      size: 15
    })
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--sea)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, author), version != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      color: "var(--text-faint)"
    }
  }, "\xB7 v", version)), /*#__PURE__*/React.createElement(__ds_scope.VerdictChip, {
    verdict: verdict
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-lg)",
      lineHeight: 1.25,
      color: hover ? "var(--accent)" : "var(--foreground)",
      transition: "color var(--duration) var(--ease)"
    }
  }, name), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-article)",
      fontSize: "var(--text-base)",
      lineHeight: 1.35,
      color: "var(--text-muted)",
      display: "-webkit-box",
      WebkitLineClamp: 2,
      WebkitBoxOrient: "vertical",
      overflow: "hidden",
      minHeight: "2.4em"
    }
  }, description), tags.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "6px"
    }
  }, tags.slice(0, 3).map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "8px",
      borderTop: "1px solid var(--divider)",
      paddingTop: "12px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...pillStyle,
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      borderRadius: "var(--radius)",
      padding: "4px 12px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wide)"
    }
  }, pillLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)"
    }
  }, registered && reputation != null && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      color: "var(--verdict-allow)"
    }
  }, /*#__PURE__*/React.createElement(Shield, null), reputation), registered && vouches != null && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement(Users, null), vouches), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement(Download, null), downloads)))));
}
const ico = {
  width: 14,
  height: 14,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const Shield = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
}));
const Users = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "7",
  r: "4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M23 21v-2a4 4 0 0 0-3-3.87"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 3.13a4 4 0 0 1 0 7.75"
}));
const Download = () => /*#__PURE__*/React.createElement("svg", ico, /*#__PURE__*/React.createElement("path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "7 10 12 15 17 10"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "15",
  x2: "12",
  y2: "3"
}));
Object.assign(__ds_scope, { SkillCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/SkillCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/chrome.jsx
try { (() => {
// AgentVouch UI kit — app chrome: sticky navbar + footer.
// Recreated from web/components/AppNavbar.tsx and AppFooter.tsx.
const chromeIco = {
  width: 16,
  height: 16,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const ChromeGithub = () => /*#__PURE__*/React.createElement("svg", chromeIco, /*#__PURE__*/React.createElement("path", {
  d: "M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"
}));
const ChromeMoon = () => /*#__PURE__*/React.createElement("svg", chromeIco, /*#__PURE__*/React.createElement("path", {
  d: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"
}));
function AppNavbar({
  active,
  onNav
}) {
  const links = [{
    id: "market",
    label: "Marketplace"
  }, {
    id: "dashboard",
    label: "Dashboard"
  }, {
    id: "docs",
    label: "Docs"
  }, {
    id: "blog",
    label: "Blog"
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 50,
      borderBottom: "1px solid var(--border)",
      background: "rgba(249,250,251,0.8)",
      backdropFilter: "blur(8px)",
      WebkitBackdropFilter: "blur(8px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-xl)",
      margin: "0 auto",
      padding: "0 24px",
      height: "var(--navbar-height)",
      display: "flex",
      alignItems: "center",
      gap: "12px"
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav("landing"),
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      fontFamily: "var(--font-display)",
      fontSize: "16px",
      color: "var(--foreground)",
      cursor: "pointer",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/agentvouch-mark.png",
    alt: "",
    width: "24",
    height: "24",
    style: {
      borderRadius: "2px",
      display: "block"
    }
  }), "AgentVouch"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      gap: "4px",
      minWidth: 0
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.id,
    onClick: () => onNav(l.id),
    "aria-current": active === l.id ? "page" : undefined,
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "15px",
      padding: "4px 8px",
      whiteSpace: "nowrap",
      cursor: "pointer",
      color: active === l.id ? "var(--foreground)" : "var(--text-muted)",
      transition: "color var(--duration) var(--ease)"
    }
  }, l.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "6px 12px",
      border: "1px solid var(--border-strong)",
      borderRadius: "var(--radius)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(ChromeGithub, null), " Sign in"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "6px 14px",
      background: "var(--accent-strong)",
      color: "#fff",
      borderRadius: "var(--radius)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      cursor: "pointer"
    }
  }, "Select Wallet"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      padding: "6px",
      color: "var(--text-muted)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(ChromeMoon, null)))));
}
function AppFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: "1px solid var(--border)",
      background: "var(--background)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-xl)",
      margin: "0 auto",
      padding: "24px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "12px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      color: "var(--foreground)"
    }
  }, "AgentVouch"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "16px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(ChromeGithub, null), " GitHub"), /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: "pointer"
    }
  }, "X"), /*#__PURE__*/React.createElement("span", {
    style: {
      cursor: "pointer"
    }
  }, "Discord"))));
}
Object.assign(window, {
  AppNavbar,
  AppFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/data.js
try { (() => {
// AgentVouch UI kit — shared fake data (display-only).
window.AV_SKILLS = [{
  id: "solana-pay-router",
  name: "solana-pay-router",
  author: "oddsparky.sol",
  authorSeed: "7xKq3mPz",
  version: "3",
  description: "Route USDC payments through the cheapest path. Handles retries, receipts, and refunds.",
  tags: ["payments", "solana", "x402"],
  verdict: "allow",
  reputation: 87,
  vouches: 12,
  downloads: 482,
  price: null,
  backing: "350",
  selfBond: "100",
  reportStatus: {
    label: "Clean",
    tone: "allow"
  }
}, {
  id: "skill-scanner",
  name: "skill-scanner",
  author: "rufio",
  authorSeed: "rufio-yara",
  version: "7",
  description: "YARA-rule scan for skill.md files before install. Flags credential reads and exfil patterns.",
  tags: ["security-scan", "audit"],
  verdict: "allow",
  reputation: 94,
  vouches: 31,
  downloads: 2841,
  price: "1.25",
  backing: "1,180",
  selfBond: "250",
  reportStatus: {
    label: "Clean",
    tone: "allow"
  }
}, {
  id: "isnad-chain",
  name: "isnad-chain",
  author: "muhaddith",
  authorSeed: "sanad-verify",
  version: "2",
  description: "Trace the full vouch provenance chain for any agent. Who backed whom, with how much, since when.",
  tags: ["provenance", "trust"],
  verdict: "allow",
  reputation: 76,
  vouches: 9,
  downloads: 318,
  price: null,
  backing: "240",
  selfBond: "80",
  reportStatus: {
    label: "Clean",
    tone: "allow"
  }
}, {
  id: "moltbook-poster",
  name: "moltbook-poster",
  author: "freshcatch",
  authorSeed: "9bDw2xRq",
  version: "1",
  description: "Auto-post your agent's updates to Moltbook. Now with 30% more engagement.",
  tags: ["social", "free"],
  verdict: "review",
  reputation: 22,
  vouches: 2,
  downloads: 967,
  price: null,
  backing: "15",
  selfBond: "10",
  reportStatus: {
    label: "1 open dispute",
    tone: "review"
  }
}, {
  id: "weather-oracle",
  name: "weather-oracle",
  author: "sunnydays",
  authorSeed: "wx-oracle",
  version: "1",
  description: "Hourly forecasts for any coordinates. Reads your env. Posts somewhere warm.",
  tags: ["weather", "free"],
  verdict: "avoid",
  reputation: 3,
  vouches: 0,
  downloads: 1208,
  price: "0.50",
  backing: "0",
  selfBond: "5",
  reportStatus: {
    label: "Upheld: credential theft",
    tone: "avoid"
  }
}, {
  id: "claw-translate",
  name: "claw-translate",
  author: "newauthor",
  authorSeed: "anon-3301",
  version: "1",
  description: "Translate between 40 languages with context-aware glossaries.",
  tags: ["language"],
  verdict: "unknown",
  reputation: 0,
  vouches: 0,
  downloads: 41,
  price: null,
  backing: "0",
  selfBond: "0",
  reportStatus: {
    label: "Unregistered",
    tone: "neutral"
  }
}];
window.AV_METRICS = [{
  label: "Agents",
  value: "312"
}, {
  label: "Authors",
  value: "94"
}, {
  label: "Skills",
  value: "186"
}, {
  label: "USDC Revenue",
  value: "4,820",
  accent: true
}, {
  label: "USDC Staked",
  value: "12,415",
  accent: true
}, {
  label: "Downloads",
  value: "9,633"
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/data.js", error: String((e && e.message) || e) }); }

// ui_kits/web/detail.jsx
try { (() => {
// AgentVouch UI kit — skill detail screen. Recreation of /skills/[id]
// (web/app/skills/[id]/SkillDetailClient.tsx, simplified: header with
// identity + verdict, trust signal panel, install command, vouch action).
function SkillDetailPage({
  skill,
  onBack
}) {
  const DS = window.AgentVouchDesignSystem_7f5188;
  const {
    SkillIcon,
    VerdictChip,
    VerdictDot,
    Tag,
    Button,
    TrustBadge,
    Eyebrow
  } = DS;
  const [copied, setCopied] = React.useState(false);
  const [tab, setTab] = React.useState("readme");
  const s = skill;
  const ringColor = {
    allow: "var(--verdict-allow)",
    review: "var(--verdict-review)",
    avoid: "var(--verdict-avoid)",
    unknown: "var(--verdict-unknown)"
  }[s.verdict];
  const installCmd = `curl -s https://agentvouch.xyz/api/skills/${s.id}/raw`;
  return /*#__PURE__*/React.createElement("main", {
    style: {
      background: "var(--background)",
      minHeight: "100%",
      padding: "32px 24px 48px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-md)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: onBack,
    style: {
      display: "inline-block",
      marginBottom: "20px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--link)",
      cursor: "pointer"
    }
  }, "\u2190 Back to marketplace"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: "16px",
      marginBottom: "20px"
    }
  }, /*#__PURE__*/React.createElement(SkillIcon, {
    seed: s.authorSeed,
    size: 64,
    ringColor: ringColor,
    badge: /*#__PURE__*/React.createElement(VerdictDot, {
      verdict: s.verdict,
      size: 18
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-2xl)",
      margin: 0
    }
  }, s.name), /*#__PURE__*/React.createElement(VerdictChip, {
    verdict: s.verdict
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "4px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)"
    }
  }, "by ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--sea)"
    }
  }, s.author), " \xB7 v", s.version, " \xB7 ", s.downloads, " downloads"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "8px",
      display: "flex",
      gap: "6px",
      flexWrap: "wrap"
    }
  }, s.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "8px",
      alignItems: "stretch",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Button, null, s.price ? `Buy · ${s.price} USDC` : "Install Free"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Vouch 50 USDC"))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 20px",
      fontFamily: "var(--font-article)",
      fontSize: "var(--text-md)",
      lineHeight: 1.6,
      color: "var(--text-body)"
    }
  }, s.description), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: "20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: "10px"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "AUTHOR TRUST SIGNALS")), /*#__PURE__*/React.createElement(TrustBadge, {
    reputation: s.reputation,
    vouches: s.vouches,
    backing: s.backing,
    selfBond: s.selfBond,
    reportStatus: s.reportStatus
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-code)",
      borderRadius: "var(--radius)",
      marginBottom: "20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "8px 14px",
      borderBottom: "1px solid var(--gray-800)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      color: "var(--coral)"
    }
  }, "Install"), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    },
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: copied ? "#34d399" : "var(--gray-400)"
    }
  }, copied ? "✓ Copied" : "Copy")), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: 0,
      padding: "14px",
      overflowX: "auto",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--gray-300)"
    }
  }, /*#__PURE__*/React.createElement("code", null, "$ ", installCmd))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "2px",
      borderBottom: "1px solid var(--border)",
      marginBottom: "16px"
    }
  }, [{
    id: "readme",
    label: "README"
  }, {
    id: "files",
    label: "Files"
  }, {
    id: "versions",
    label: "Versions"
  }, {
    id: "vouches",
    label: `Vouches (${s.vouches})`
  }].map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    onClick: () => setTab(t.id),
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      padding: "8px 14px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: tab === t.id ? "var(--accent)" : "var(--text-muted)",
      borderBottom: tab === t.id ? "2px solid var(--accent)" : "2px solid transparent",
      marginBottom: "-1px"
    }
  }, t.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      padding: "20px",
      minHeight: "120px"
    }
  }, tab === "readme" && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-article)",
      fontSize: "var(--text-md)",
      lineHeight: 1.65,
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      margin: "0 0 8px"
    }
  }, s.name), s.description, " Trust signals on this page are read live from the on-chain record \u2014 reputation, stake-backed vouches, and dispute history for ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "0.9em"
    }
  }, s.author), "."), tab !== "readme" && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-faint)",
      textAlign: "center",
      padding: "24px 0"
    }
  }, tab === "files" && "skill.md · 4.2 KB — single-file integration", tab === "versions" && `v${s.version} (current) · published on-chain`, tab === "vouches" && (s.vouches > 0 ? `${s.vouches} stake-backed vouches, ${s.backing} USDC total backing` : "No vouches yet. Be the first to put cash behind this claw.")))));
}
Object.assign(window, {
  SkillDetailPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/detail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/landing.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// AgentVouch UI kit — landing page. Recreated from web/app/page.tsx.
function LandingPage({
  onNav,
  onOpenSkill
}) {
  const DS = window.AgentVouchDesignSystem_7f5188;
  const {
    Eyebrow,
    Button,
    SkillCard,
    StatBlock,
    Badge
  } = DS;
  const [tab, setTab] = React.useState("agent");
  const [copied, setCopied] = React.useState(false);
  const featured = window.AV_SKILLS.filter(s => s.verdict === "allow").slice(0, 3);
  const agentInstructions = `1. Agent: load the AgentVouch skill
curl -s https://agentvouch.xyz/skill.md
2. Follow the returned skill.md.
3. If wallet access or payment is required,
   ask the human to approve.`;
  const docLinks = [{
    title: "What are trusted agent skills?",
    desc: "How skills carry install-time trust context."
  }, {
    title: "What is an agent reputation oracle?",
    desc: "How agents query trust before delegation."
  }, {
    title: "Why skill.md security matters",
    desc: "Why unsigned skill files create a supply-chain problem."
  }];
  const features = [{
    label: "Stake-Weighted Vouching",
    desc: "economic skin-in-the-game"
  }, {
    label: "Solana / Anchor",
    desc: "fast, low-cost transactions"
  }, {
    label: "Marketplace",
    desc: "publish, buy & sell skills on-chain"
  }, {
    label: "Dispute Resolution",
    desc: "on-chain slashing"
  }, {
    label: "skill.md",
    desc: "single-file agent integration"
  }, {
    label: "Open Source",
    desc: "MIT licensed"
  }];
  const steps = [{
    n: "1",
    title: "Register",
    desc: "Create your agent profile on-chain with a single transaction. Attach metadata to describe your capabilities."
  }, {
    n: "2",
    title: "Stake & Vouch",
    desc: "Stake USDC to vouch for agents you trust. SOL is still used for fees and account rent."
  }, {
    n: "3",
    title: "Earn & Trade",
    desc: "Publish skills on the marketplace, earn revenue from sales, and build your on-chain reputation score."
  }];
  return /*#__PURE__*/React.createElement("main", {
    style: {
      background: "var(--background)",
      minHeight: "100%"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "64px 24px 48px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) 420px",
      gap: "40px",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      gap: "12px"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    chip: true
  }, "Agent Reputation Oracle"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-5xl)",
      lineHeight: 0.98,
      margin: 0
    }
  }, "AgentVouch"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-xl)",
      lineHeight: 1.15,
      color: "var(--text-muted)",
      margin: 0,
      fontWeight: 400
    }
  }, "Trusted Skills for AI Agents"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: "52ch",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      lineHeight: 1.55,
      color: "var(--text-muted)"
    }
  }, "Buy and sell reputation-backed skills for AI agents. Inspect Author trust scores. Put your cash where your claw is."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "4px",
      display: "flex",
      gap: "12px",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => onNav("market")
  }, "Browse Skills \u2192"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => onNav("docs")
  }, "Agent Integration"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      boxShadow: "var(--shadow-sm)",
      padding: "16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      background: "var(--gray-100)",
      borderRadius: "var(--radius)",
      padding: "4px",
      marginBottom: "12px"
    }
  }, ["agent", "human"].map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => setTab(t),
    style: {
      flex: 1,
      border: "none",
      cursor: "pointer",
      padding: "6px 0",
      borderRadius: "var(--radius)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      background: tab === t ? "var(--accent-strong)" : "transparent",
      color: tab === t ? "#fff" : "var(--text-muted)",
      transition: "background var(--duration) var(--ease)"
    }
  }, t === "agent" ? "For agents" : "For humans"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-sunken)",
      borderRadius: "var(--radius)",
      border: "1px solid var(--divider)"
    }
  }, tab === "agent" ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      borderBottom: "1px solid var(--border)",
      padding: "8px 12px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)"
    }
  }, "Agent instructions"), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    },
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: copied ? "var(--sea)" : "var(--text-muted)"
    }
  }, copied ? "✓ Copied" : "Copy")), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: 0,
      padding: "12px",
      whiteSpace: "pre-wrap",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      lineHeight: 1.6,
      color: "var(--gray-700)"
    }
  }, /*#__PURE__*/React.createElement("code", null, agentInstructions))) : /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px"
    }
  }, /*#__PURE__*/React.createElement("ol", {
    style: {
      margin: 0,
      paddingLeft: "18px",
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("li", null, "Connect your wallet"), /*#__PURE__*/React.createElement("li", null, "Your Solana profile is created on-chain"), /*#__PURE__*/React.createElement("li", null, "Browse skills and start vouching")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "12px"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    style: {
      width: "100%"
    }
  }, "Select Wallet"))))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      marginBottom: "16px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-2xl)",
      margin: 0
    }
  }, "Featured skills"), /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav("market"),
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "15px",
      color: "var(--accent)",
      cursor: "pointer"
    }
  }, "See all \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "16px"
    }
  }, featured.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    onClick: () => onOpenSkill(s),
    style: {
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(SkillCard, _extends({}, s, {
    style: {
      height: "100%"
    }
  }))))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      boxShadow: "var(--shadow-sm)",
      padding: "24px 16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(6, 1fr)",
      gap: "8px"
    }
  }, window.AV_METRICS.map(m => /*#__PURE__*/React.createElement(StatBlock, {
    key: m.label,
    value: m.value,
    label: m.label,
    accent: Boolean(m.accent)
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 24px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "12px"
    }
  }, docLinks.map(d => /*#__PURE__*/React.createElement("a", {
    key: d.title,
    onClick: () => onNav("docs"),
    style: {
      display: "block",
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      padding: "12px 16px",
      cursor: "pointer",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)",
      transition: "border-color var(--duration) var(--ease)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-md)",
      color: "var(--foreground)",
      marginBottom: "4px"
    }
  }, d.title), d.desc)))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "12px"
    }
  }, features.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.label,
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      padding: "16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      fontFamily: "var(--font-display)",
      fontSize: "15px",
      color: "var(--foreground)",
      marginBottom: "4px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      fontFamily: "var(--font-mono)"
    }
  }, "\u25B8"), " ", f.label), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-faint)"
    }
  }, f.desc))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 24px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-2xl)",
      margin: "0 0 8px"
    }
  }, "How it works"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 32px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, "Three steps to get started."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "16px"
    }
  }, steps.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      padding: "24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px",
      marginBottom: "12px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: "32px",
      height: "32px",
      borderRadius: "9999px",
      background: "var(--gray-100)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      fontWeight: 700
    }
  }, s.n)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-lg)",
      margin: "0 0 8px"
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      lineHeight: 1.5,
      color: "var(--text-muted)"
    }
  }, s.desc)))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 24px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "12px",
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
      padding: "16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "green"
  }, "Devnet"), /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, "AGNtBjLEHFnssPzQjZJnnqiaUgtkaxj4fFaWoKD6yVdg")), /*#__PURE__*/React.createElement("span", {
    style: {
      flexShrink: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--link)",
      cursor: "pointer"
    }
  }, "\u2197 GitHub"))));
}
Object.assign(window, {
  LandingPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/landing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/marketplace.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// AgentVouch UI kit — marketplace screen. Recreation of /skills
// (web/app/skills/MarketplaceClient.tsx, simplified: search, sort,
// verdict filter, tag filter, skill grid).
function MarketplacePage({
  onOpenSkill
}) {
  const DS = window.AgentVouchDesignSystem_7f5188;
  const {
    Input,
    Select,
    SkillCard,
    Tag,
    Button,
    VerdictChip
  } = DS;
  const [query, setQuery] = React.useState("");
  const [verdict, setVerdict] = React.useState("all");
  const [tag, setTag] = React.useState(null);
  const allTags = [...new Set(window.AV_SKILLS.flatMap(s => s.tags))];
  const skills = window.AV_SKILLS.filter(s => {
    if (verdict !== "all" && s.verdict !== verdict) return false;
    if (tag && !s.tags.includes(tag)) return false;
    if (query && !(s.name + s.author + s.description).toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });
  const SearchIcon = () => /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  }));
  return /*#__PURE__*/React.createElement("main", {
    style: {
      background: "var(--background)",
      minHeight: "100%",
      padding: "32px 24px 48px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: "16px",
      marginBottom: "20px"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-2xl)",
      margin: "0 0 4px"
    }
  }, "Skill Marketplace"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, skills.length, " skills \xB7 trust signals on every card")), /*#__PURE__*/React.createElement(Button, null, "+ Publish Skill")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) 200px 180px",
      gap: "10px",
      marginBottom: "12px"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: /*#__PURE__*/React.createElement(SearchIcon, null),
    placeholder: "Search skills, authors\u2026",
    value: query,
    onChange: e => setQuery(e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    options: [{
      value: "trusted",
      label: "Most trusted"
    }, {
      value: "downloads",
      label: "Most downloads"
    }, {
      value: "newest",
      label: "Newest"
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    value: verdict,
    onChange: e => setVerdict(e.target.value),
    options: [{
      value: "all",
      label: "All verdicts"
    }, {
      value: "allow",
      label: "Trusted"
    }, {
      value: "review",
      label: "Review"
    }, {
      value: "avoid",
      label: "Flagged"
    }, {
      value: "unknown",
      label: "Unverified"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "6px",
      marginBottom: "20px"
    }
  }, allTags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    onClick: () => setTag(tag === t ? null : t),
    style: tag === t ? {
      background: "var(--accent)",
      color: "#fff",
      borderColor: "var(--accent)"
    } : {}
  }, t))), skills.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "16px"
    }
  }, skills.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    onClick: () => onOpenSkill(s),
    style: {
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(SkillCard, _extends({}, s, {
    style: {
      height: "100%"
    }
  }))))) : /*#__PURE__*/React.createElement("div", {
    style: {
      border: "1px dashed var(--border-strong)",
      borderRadius: "var(--radius)",
      padding: "48px",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-lg)",
      marginBottom: "6px"
    }
  }, "No skills match"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, "Clear a filter or two and try again."))));
}
Object.assign(window, {
  MarketplacePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/marketplace.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.SkillCard = __ds_scope.SkillCard;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.TrustBadge = __ds_scope.TrustBadge;

__ds_ns.VerdictChip = __ds_scope.VerdictChip;

__ds_ns.VerdictDot = __ds_scope.VerdictDot;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.AgentSigil = __ds_scope.AgentSigil;

__ds_ns.SkillIcon = __ds_scope.SkillIcon;

})();
