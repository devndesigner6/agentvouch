import * as React from "react";

export interface BadgeProps {
  children?: React.ReactNode;
  /** Color tone. @default "neutral" */
  tone?: "neutral" | "coral" | "sea" | "allow" | "review" | "avoid" | "green";
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Small uppercase mono status pill (network status, tier, state flags). */
export function Badge(props: BadgeProps): JSX.Element;
