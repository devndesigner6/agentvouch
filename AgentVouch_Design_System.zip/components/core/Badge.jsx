import React from "react";

/**
 * Badge — a small status pill. Uppercase mono, tracked. Used for network
 * status ("Devnet"), tiers, and state flags. Tones map to the brand's
 * accent + verdict palette.
 */
export function Badge({ children, tone = "neutral", icon = null, style = {}, ...rest }) {
  const tones = {
    neutral: { bg: "var(--gray-100)", fg: "var(--gray-600)", bd: "var(--border)" },
    coral: { bg: "var(--coral-soft)", fg: "var(--accent-on-soft)", bd: "var(--coral-border)" },
    sea: { bg: "var(--sea-soft)", fg: "var(--sea-strong)", bd: "var(--sea-border)" },
    allow: { bg: "var(--verdict-allow-soft)", fg: "var(--verdict-allow)", bd: "var(--verdict-allow-border)" },
    review: { bg: "var(--verdict-review-soft)", fg: "var(--verdict-review)", bd: "var(--verdict-review-border)" },
    avoid: { bg: "var(--verdict-avoid-soft)", fg: "var(--verdict-avoid)", bd: "var(--verdict-avoid-border)" },
    green: { bg: "rgba(5,150,105,0.1)", fg: "var(--verdict-allow)", bd: "var(--verdict-allow-border)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        padding: "2px 8px",
        background: t.bg,
        color: t.fg,
        border: `1px solid ${t.bd}`,
        borderRadius: "var(--radius-full)",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-2xs)",
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        lineHeight: 1.4,
        whiteSpace: "nowrap",
        ...style,
      }}
      {...rest}
    >
      {icon && <span style={{ display: "inline-flex" }}>{icon}</span>}
      {children}
    </span>
  );
}
