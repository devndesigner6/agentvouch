import * as React from "react";

/**
 * @startingPoint section="Core" subtitle="Buttons in every variant & size" viewport="700x200"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual style. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "danger";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  /** Icon node placed before the label (e.g. a Feather icon). */
  iconLeft?: React.ReactNode;
  /** Icon node placed after the label. */
  iconRight?: React.ReactNode;
  /** Render as another element/tag, e.g. "a". @default "button" */
  as?: keyof JSX.IntrinsicElements;
  style?: React.CSSProperties;
  [key: string]: unknown;
}

/**
 * Primary interactive control for AgentVouch — mono type, sharp corners,
 * solid ember-coral primary with a soft sea-teal secondary.
 */
export function Button(props: ButtonProps): JSX.Element;
