import React from "react";

/**
 * AgentVouch Button — the primary interactive control.
 *
 * Mono type, sharp 6px corners, no uppercase by default. The primary
 * variant is solid ember coral; secondary is a soft sea-teal capsule with
 * a hairline border; ghost is text-only; danger reuses ember for
 * destructive/slashing actions. Hover deepens the fill (primary) or the
 * soft wash (secondary); disabled drops to a flat gray.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: "5px 10px", fontSize: "var(--text-xs)", gap: "5px" },
    md: { padding: "7px 14px", fontSize: "var(--text-sm)", gap: "8px" },
    lg: { padding: "10px 20px", fontSize: "var(--text-base)", gap: "8px" },
  };

  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "var(--font-mono)",
    fontWeight: 400,
    lineHeight: 1,
    borderRadius: "var(--radius)",
    border: "1px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "background var(--duration) var(--ease), border-color var(--duration) var(--ease), color var(--duration) var(--ease)",
    whiteSpace: "nowrap",
    textDecoration: "none",
    ...sizes[size],
  };

  const variants = {
    primary: {
      background: "var(--accent-strong)",
      color: "var(--text-on-accent)",
    },
    secondary: {
      background: "var(--sea-soft)",
      color: "var(--sea-strong)",
      borderColor: "var(--sea-border)",
    },
    ghost: {
      background: "transparent",
      color: "var(--text-muted)",
    },
    danger: {
      background: "var(--ember)",
      color: "#fff",
    },
  };

  const disabledStyle = disabled
    ? { background: "var(--gray-300)", color: "var(--gray-500)", borderColor: "transparent" }
    : {};

  const hover = {
    primary: { background: "var(--accent)" },
    secondary: { background: "var(--sea-soft-hover)" },
    ghost: { color: "var(--accent)" },
    danger: { background: "var(--coral-muted)" },
  };

  const handleEnter = (e) => {
    if (disabled) return;
    Object.assign(e.currentTarget.style, hover[variant]);
  };
  const handleLeave = (e) => {
    if (disabled) return;
    Object.assign(e.currentTarget.style, {
      background: variants[variant].background,
      color: variants[variant].color,
    });
  };

  const Tag = as;
  return (
    <Tag
      style={{ ...base, ...variants[variant], ...disabledStyle, ...style }}
      disabled={as === "button" ? disabled : undefined}
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
      {...rest}
    >
      {iconLeft && <span style={{ display: "inline-flex" }}>{iconLeft}</span>}
      {children}
      {iconRight && <span style={{ display: "inline-flex" }}>{iconRight}</span>}
    </Tag>
  );
}
