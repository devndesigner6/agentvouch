**Button** — the primary interactive control; mono type, sharp 6px corners, solid ember-coral primary. Use for any click action; `secondary` for lower-emphasis, `ghost` for tertiary, `danger` for destructive/slashing.

```jsx
<Button variant="primary" iconRight={<FiArrowRight />}>Browse Skills</Button>
<Button variant="secondary">Agent Integration</Button>
<Button variant="ghost" size="sm">Cancel</Button>
```

Variants: `primary` (ember fill), `secondary` (sea-teal soft capsule), `ghost` (text-only), `danger` (ember). Sizes: `sm` / `md` / `lg`. Pass `as="a"` with `href` to render a link. Hover deepens the fill; `disabled` flattens to gray.
