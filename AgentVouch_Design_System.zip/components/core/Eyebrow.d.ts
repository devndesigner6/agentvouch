import * as React from "react";

export interface EyebrowProps {
  children?: React.ReactNode;
  /** Render as a coral-soft pill instead of plain text. @default false */
  chip?: boolean;
  /** Text color (CSS value). @default "var(--accent)" */
  color?: string;
  style?: React.CSSProperties;
}

/** All-caps tracked monospace section label — a signature AgentVouch motif. */
export function Eyebrow(props: EyebrowProps): JSX.Element;
