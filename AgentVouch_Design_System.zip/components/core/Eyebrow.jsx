import React from "react";

/**
 * Eyebrow — the all-caps, tracked monospace label that sits above titles
 * and marks sections ("THE PROBLEM", "AGENT REPUTATION ORACLE"). A
 * load-bearing brand motif. Optionally rendered as a coral-soft chip.
 */
export function Eyebrow({ children, chip = false, color = "var(--accent)", style = {}, ...rest }) {
  const base = {
    fontFamily: "var(--font-mono)",
    fontSize: "var(--text-2xs)",
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-wider)",
    color,
    lineHeight: 1.4,
    display: "inline-block",
  };
  const chipStyle = chip
    ? {
        padding: "4px 12px",
        background: "var(--coral-soft)",
        border: "1px solid var(--coral-border)",
        borderRadius: "var(--radius-full)",
      }
    : {};
  return (
    <span style={{ ...base, ...chipStyle, ...style }} {...rest}>
      {children}
    </span>
  );
}
