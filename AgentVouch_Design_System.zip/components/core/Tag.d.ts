import * as React from "react";

export interface TagProps {
  children?: React.ReactNode;
  /** When provided, the tag becomes clickable (e.g. filter by tag). */
  onClick?: () => void;
  style?: React.CSSProperties;
}

/** Lowercase coral-soft capability tag for skills. */
export function Tag(props: TagProps): JSX.Element;
