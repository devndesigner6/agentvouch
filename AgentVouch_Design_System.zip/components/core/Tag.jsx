import React from "react";

/**
 * Tag — a lowercase capability tag for skills. Coral-soft capsule with a
 * coral hairline border. Always lowercase; reads as a quiet metadata token,
 * not a loud chip. Optionally clickable (filter by tag).
 */
export function Tag({ children, onClick = null, style = {}, ...rest }) {
  const interactive = typeof onClick === "function";
  return (
    <span
      role={interactive ? "button" : undefined}
      tabIndex={interactive ? 0 : undefined}
      onClick={onClick}
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "2px 8px",
        background: "var(--coral-soft)",
        color: "var(--accent-on-soft)",
        border: "1px solid var(--coral-border)",
        borderRadius: "var(--radius-full)",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-2xs)",
        textTransform: "lowercase",
        letterSpacing: "var(--tracking-wide)",
        lineHeight: 1.5,
        cursor: interactive ? "pointer" : "default",
        transition: "border-color var(--duration) var(--ease), background var(--duration) var(--ease)",
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
