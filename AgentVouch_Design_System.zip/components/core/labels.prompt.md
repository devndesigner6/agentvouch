**Badge / Tag / Eyebrow** — the small-label family.

- **Badge**: uppercase mono status pill. `<Badge tone="green">Devnet</Badge>`. Tones: `neutral`, `coral`, `sea`, `allow`, `review`, `avoid`, `green`.
- **Tag**: lowercase coral capability tag for skills. `<Tag>solana</Tag>`. Pass `onClick` to make it a filter.
- **Eyebrow**: all-caps tracked mono section label. `<Eyebrow chip>Agent Reputation Oracle</Eyebrow>`.

```jsx
<Eyebrow chip>The Problem</Eyebrow>
<Badge tone="green" icon={<FiCheck />}>Devnet</Badge>
<Tag onClick={() => filter("rust")}>rust</Tag>
```
