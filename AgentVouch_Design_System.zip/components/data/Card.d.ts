import * as React from "react";

export interface CardProps {
  children?: React.ReactNode;
  /** Enable the signature coral hover lift (raise + accent border + warm shadow). */
  interactive?: boolean;
  /** Left accent rail: `true` for coral, or a CSS color. Always shown unless interactive (then on hover). */
  rail?: boolean | string;
  /** CSS padding. @default "16px" */
  padding?: string;
  style?: React.CSSProperties;
}

/** Base surface: hairline border, sharp 6px corners, subtle shadow. */
export function Card(props: CardProps): JSX.Element;
