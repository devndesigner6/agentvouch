import React from "react";

/**
 * Card — the base surface. White (or ink) fill, 1px hairline border, sharp
 * 6px corners, subtle shadow. Set `interactive` for the signature coral hover
 * lift (raise + coral border + warm shadow). Optional left `rail` accent.
 */
export function Card({ children, interactive = false, rail = null, padding = "16px", style = {}, ...rest }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => interactive && setHover(true)}
      onMouseLeave={() => interactive && setHover(false)}
      style={{
        position: "relative",
        overflow: "hidden",
        background: "var(--surface)",
        border: `1px solid ${hover ? "var(--accent-border)" : "var(--border)"}`,
        borderRadius: "var(--radius)",
        boxShadow: hover ? "var(--shadow-coral)" : "var(--shadow-sm)",
        transform: hover ? "translateY(-2px)" : "translateY(0)",
        transition: "transform var(--duration) var(--ease), border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
        padding,
        ...style,
      }}
      {...rest}
    >
      {rail && (
        <span
          aria-hidden
          style={{
            position: "absolute",
            insetBlock: 0,
            left: 0,
            width: "var(--rail-width)",
            background: rail === true ? "var(--accent)" : rail,
            opacity: interactive ? (hover ? 1 : 0) : 1,
            transition: "opacity var(--duration) var(--ease)",
          }}
        />
      )}
      {children}
    </div>
  );
}
