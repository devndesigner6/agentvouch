import * as React from "react";

/**
 * @startingPoint section="Marketplace" subtitle="Trust-signal skill card" viewport="380x300"
 */
export interface SkillCardProps {
  name: string;
  /** Author label (handle or short address), shown in the byline. */
  author: string;
  /** Stable seed for the generative sigil (wallet/pubkey). Falls back to author/name. */
  authorSeed?: string;
  description?: string;
  tags?: string[];
  /** Trust verdict — drives the chip, dot, and accent rail color. @default "unknown" */
  verdict?: "allow" | "review" | "avoid" | "unknown";
  reputation?: number | null;
  vouches?: number | null;
  downloads?: number;
  version?: number | null;
  /** USDC price string; omit/null for a free "Get" skill. */
  price?: string | null;
  installed?: boolean;
  style?: React.CSSProperties;
}

/**
 * The marketplace's core unit — a published skill with author identity, trust
 * verdict, capability tags, and a stat row. Composes SkillIcon, VerdictChip, Tag.
 */
export function SkillCard(props: SkillCardProps): JSX.Element;
