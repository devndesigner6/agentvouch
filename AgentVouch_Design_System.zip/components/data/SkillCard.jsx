import React from "react";
import { SkillIcon } from "../identity/SkillIcon.jsx";
import { VerdictChip, VerdictDot } from "../feedback/VerdictChip.jsx";
import { Tag } from "../core/Tag.jsx";

/**
 * SkillCard — the marketplace's core unit: a published skill with its author
 * identity, trust verdict, description, capability tags, and bottom stat row
 * (action pill · reputation · vouches · downloads). Composes SkillIcon,
 * VerdictChip/Dot, and Tag. Hover gives the signature coral lift + accent rail.
 */
const RING = {
  allow: "var(--verdict-allow)",
  review: "var(--verdict-review)",
  avoid: "var(--verdict-avoid)",
  unknown: "var(--verdict-unknown)",
};

export function SkillCard({
  name,
  author,
  authorSeed,
  description,
  tags = [],
  verdict = "unknown",
  reputation = null,
  vouches = null,
  downloads = 0,
  version = null,
  price = null, // null/"Get" → free; string → USDC price
  installed = false,
  style = {},
}) {
  const [hover, setHover] = React.useState(false);
  const registered = verdict !== "unknown";
  const pillLabel = installed ? "Installed" : price ? `${price} USDC` : "Get";
  const pillStyle = installed
    ? { background: "var(--verdict-allow-soft)", color: "var(--verdict-allow)", border: "1px solid var(--verdict-allow-border)" }
    : { background: "var(--accent)", color: "#fff", border: "1px solid transparent" };

  return (
    <article
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        background: "var(--surface)",
        border: `1px solid ${hover ? "var(--accent-border)" : "var(--border)"}`,
        borderRadius: "var(--radius)",
        boxShadow: hover ? "var(--shadow-coral)" : "var(--shadow-sm)",
        transform: hover ? "translateY(-2px)" : "translateY(0)",
        transition: "transform var(--duration) var(--ease), border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
        ...style,
      }}
    >
      <span aria-hidden style={{ position: "absolute", insetBlock: 0, left: 0, width: "var(--rail-width)", background: RING[verdict], opacity: hover ? 1 : 0, transition: "opacity var(--duration) var(--ease)" }} />

      <div style={{ display: "flex", flexDirection: "column", gap: "10px", padding: "16px", flex: 1 }}>
        {/* byline + verdict */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
            <SkillIcon seed={authorSeed || author || name} size={30} ringColor={RING[verdict]} badge={<VerdictDot verdict={verdict} size={15} />} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--sea)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {author}
            </span>
            {version != null && (
              <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-2xs)", color: "var(--text-faint)" }}>· v{version}</span>
            )}
          </div>
          <VerdictChip verdict={verdict} />
        </div>

        {/* title */}
        <div style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-lg)", lineHeight: 1.25, color: hover ? "var(--accent)" : "var(--foreground)", transition: "color var(--duration) var(--ease)" }}>
          {name}
        </div>

        {/* description */}
        {description && (
          <p style={{ margin: 0, fontFamily: "var(--font-article)", fontSize: "var(--text-base)", lineHeight: 1.35, color: "var(--text-muted)", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", minHeight: "2.4em" }}>
            {description}
          </p>
        )}

        {/* tags */}
        {tags.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
            {tags.slice(0, 3).map((t) => (<Tag key={t}>{t}</Tag>))}
          </div>
        )}

        {/* stat row */}
        <div style={{ marginTop: "auto", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px", borderTop: "1px solid var(--divider)", paddingTop: "12px" }}>
          <span style={{ ...pillStyle, display: "inline-flex", alignItems: "center", gap: "6px", borderRadius: "var(--radius)", padding: "4px 12px", fontFamily: "var(--font-mono)", fontSize: "var(--text-2xs)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "var(--tracking-wide)" }}>
            {pillLabel}
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: "12px", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)" }}>
            {registered && reputation != null && (
              <span style={{ display: "inline-flex", alignItems: "center", gap: "4px", color: "var(--verdict-allow)" }}><Shield />{reputation}</span>
            )}
            {registered && vouches != null && (
              <span style={{ display: "inline-flex", alignItems: "center", gap: "4px", color: "var(--text-muted)" }}><Users />{vouches}</span>
            )}
            <span style={{ display: "inline-flex", alignItems: "center", gap: "4px", color: "var(--text-muted)" }}><Download />{downloads}</span>
          </div>
        </div>
      </div>
    </article>
  );
}

const ico = { width: 14, height: 14, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
const Shield = () => (<svg {...ico}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>);
const Users = () => (<svg {...ico}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>);
const Download = () => (<svg {...ico}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" /></svg>);
