import * as React from "react";

export interface StatBlockProps {
  value: React.ReactNode;
  label: React.ReactNode;
  /** Coral number when true, foreground when false. @default true */
  accent?: boolean;
  /** @default "center" */
  align?: "left" | "center" | "right";
  /** @default "lg" */
  size?: "md" | "lg" | "xl";
  style?: React.CSSProperties;
}

/** Big serif coral metric with a small tracked-mono label — the brand stat callout. */
export function StatBlock(props: StatBlockProps): JSX.Element;
