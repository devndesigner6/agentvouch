import React from "react";

/**
 * StatBlock — a big coral number with a small tracked mono label beneath.
 * The brand's signature metric callout (landing stats, dispute counts,
 * staked totals). Serif display numerals, coral by default.
 */
export function StatBlock({ value, label, accent = true, align = "center", size = "lg", style = {} }) {
  const sizes = { md: "var(--text-2xl)", lg: "var(--text-3xl)", xl: "var(--text-4xl)" };
  return (
    <div style={{ textAlign: align, ...style }}>
      <div
        style={{
          fontFamily: "var(--font-display)",
          fontSize: sizes[size] || sizes.lg,
          lineHeight: 1,
          color: accent ? "var(--accent)" : "var(--foreground)",
          marginBottom: "6px",
        }}
      >
        {value}
      </div>
      <div
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: "var(--text-2xs)",
          fontWeight: 500,
          textTransform: "uppercase",
          letterSpacing: "var(--tracking-wider)",
          color: "var(--text-faint)",
        }}
      >
        {label}
      </div>
    </div>
  );
}
