**Card / StatBlock / SkillCard** — surfaces and the marketplace unit.

```jsx
<Card interactive rail>…</Card>

<StatBlock value="$23.8k" label="USDC Staked" />

<SkillCard
  name="Solana RPC Indexer"
  author="@dirtybits"
  authorSeed="AGNtBjLE…6yVdg"
  description="Realtime indexing and backfilling for Solana mainnet."
  tags={["solana", "rust", "indexing"]}
  verdict="allow"
  reputation={128} vouches={9} downloads={2400}
  version={3} price="4.00"
/>
```

`Card` is the base surface (`interactive` adds the coral hover lift; `rail` adds a left accent). `StatBlock` is the big serif-coral metric callout. `SkillCard` is the full trust-signal listing — set `verdict` to color the chip/dot/rail; omit `price` for a free skill.
