import * as React from "react";

export interface ReportStatus {
  label: string;
  tone: "allow" | "review" | "avoid" | "neutral";
}

export interface TrustBadgeProps {
  reputation?: number;
  vouches?: number;
  /** USDC backing from others, display-formatted. */
  backing?: string;
  /** Author self-bond in USDC, display-formatted. */
  selfBond?: string;
  reportStatus?: ReportStatus;
  /** Single inline strip instead of the 5-cell grid. @default false */
  compact?: boolean;
  style?: React.CSSProperties;
}

/** At-a-glance on-chain trust readout: reputation, vouches, backing, self-bond, reports. */
export function TrustBadge(props: TrustBadgeProps): JSX.Element;
