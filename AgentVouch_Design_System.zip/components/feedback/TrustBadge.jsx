import React from "react";

/**
 * TrustBadge — the at-a-glance on-chain trust readout for an author. Renders
 * the five core trust signals as a row of compact stat cells: reputation,
 * vouches received, USDC backing from others, the author's own self-bond,
 * and report/dispute status. `compact` renders a single inline strip instead.
 *
 * Values are display-ready strings/numbers (format USDC upstream).
 */
export function TrustBadge({
  reputation = 0,
  vouches = 0,
  backing = "0",
  selfBond = "0",
  reportStatus = { label: "Clean", tone: "allow" },
  compact = false,
  style = {},
}) {
  const toneColor = {
    allow: "var(--verdict-allow)",
    review: "var(--verdict-review)",
    avoid: "var(--verdict-avoid)",
    neutral: "var(--text-muted)",
  }[reportStatus.tone || "allow"];

  if (compact) {
    return (
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "12px", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", ...style }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: "5px", color: "var(--verdict-allow)" }}>
          <Shield /> {reputation}
        </span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: "5px", color: "var(--accent)" }}>
          <Users /> {vouches}
        </span>
        <span style={{ color: "var(--text-muted)" }}>Backing {backing} USDC</span>
        <span style={{ color: "var(--text-muted)" }}>Self {selfBond} USDC</span>
        <span style={{ color: toneColor }}>⚠ {reportStatus.label}</span>
      </div>
    );
  }

  const cells = [
    { icon: <Shield />, value: reputation, label: "Reputation", color: "var(--verdict-allow)" },
    { icon: <Users />, value: vouches, label: "Vouches", color: "var(--accent)" },
    { icon: <Coins />, value: backing, label: "Backing", color: "var(--accent)" },
    { icon: <User />, value: selfBond, label: "Self Stake", color: "var(--sea)" },
    { icon: <Warn />, value: reportStatus.label, label: "Reports", color: toneColor, small: true },
  ];

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(5, minmax(0,1fr))", gap: "12px", ...style }}>
      {cells.map((c) => (
        <div
          key={c.label}
          style={{
            border: "1px solid var(--border)",
            background: "var(--surface-sunken)",
            borderRadius: "var(--radius)",
            padding: "12px 8px",
            textAlign: "center",
          }}
        >
          <div style={{ color: c.color, marginBottom: "4px", display: "flex", justifyContent: "center" }}>{c.icon}</div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: c.small ? "var(--text-sm)" : "var(--text-lg)", fontWeight: 700, color: "var(--foreground)" }}>{c.value}</div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-muted)", marginTop: "2px" }}>{c.label}</div>
        </div>
      ))}
    </div>
  );
}

/* Minimal inline Feather-style glyphs (stroke 2, 16px) to keep the component
   dependency-free. In product, swap for react-icons/fi equivalents. */
const ico = { width: 16, height: 16, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
const Shield = () => (<svg {...ico}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>);
const Users = () => (<svg {...ico}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>);
const Coins = () => (<svg {...ico}><circle cx="8" cy="8" r="6" /><path d="M18.09 10.37A6 6 0 1 1 10.34 18" /><path d="M7 6h1v4" /></svg>);
const User = () => (<svg {...ico}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>);
const Warn = () => (<svg {...ico}><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></svg>);
