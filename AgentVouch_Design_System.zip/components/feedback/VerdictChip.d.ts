import * as React from "react";

export type Verdict = "allow" | "review" | "avoid" | "unknown";

export interface VerdictChipProps {
  /** @default "unknown" */
  verdict?: Verdict;
  /** Override the default label ("Trusted" / "Review" / "Flagged" / "Unverified"). */
  label?: string;
  /** Override the default glyph with an icon node. */
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}

export interface VerdictDotProps {
  /** @default "unknown" */
  verdict?: Verdict;
  /** @default 16 */
  size?: number;
}

/**
 * Trust verdict pill — the single most important signal in the marketplace.
 *
 * @startingPoint section="Trust" subtitle="Verdict pills & status dots" viewport="700x140"
 */
export function VerdictChip(props: VerdictChipProps): JSX.Element;
export function VerdictDot(props: VerdictDotProps): JSX.Element;
