import React from "react";

/**
 * VerdictChip — the trust verdict pill that summarizes an author's on-chain
 * standing at a glance. Four states map to the verdict scale:
 *   allow   → Trusted   (emerald)
 *   review  → Review    (amber)
 *   avoid   → Flagged   (red)
 *   unknown → Unverified (gray)
 * Uppercase mono, fully-rounded, hairline border on a soft tinted fill.
 */
const META = {
  allow: { label: "Trusted", glyph: "✓", fg: "var(--verdict-allow)", bg: "var(--verdict-allow-soft)", bd: "var(--verdict-allow-border)" },
  review: { label: "Review", glyph: "!", fg: "var(--verdict-review)", bg: "var(--verdict-review-soft)", bd: "var(--verdict-review-border)" },
  avoid: { label: "Flagged", glyph: "!", fg: "var(--verdict-avoid)", bg: "var(--verdict-avoid-soft)", bd: "var(--verdict-avoid-border)" },
  unknown: { label: "Unverified", glyph: "◇", fg: "var(--verdict-unknown)", bg: "var(--verdict-unknown-soft)", bd: "var(--verdict-unknown-border)" },
};

export function VerdictChip({ verdict = "unknown", label = null, icon = null, style = {}, ...rest }) {
  const m = META[verdict] || META.unknown;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        padding: "2px 9px",
        background: m.bg,
        color: m.fg,
        border: `1px solid ${m.bd}`,
        borderRadius: "var(--radius-full)",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-2xs)",
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        lineHeight: 1.4,
        whiteSpace: "nowrap",
        ...style,
      }}
      title={m.label}
      {...rest}
    >
      <span style={{ display: "inline-flex", fontSize: "0.9em" }}>{icon || m.glyph}</span>
      {label || m.label}
    </span>
  );
}

/**
 * VerdictDot — the tiny ring-bordered status dot used as a corner badge on
 * a SkillIcon. Same four states as VerdictChip.
 */
export function VerdictDot({ verdict = "unknown", size = 16 }) {
  const m = META[verdict] || META.unknown;
  const solid = {
    allow: "var(--verdict-allow)",
    review: "var(--verdict-review)",
    avoid: "var(--verdict-avoid)",
    unknown: "var(--verdict-unknown)",
  }[verdict];
  return (
    <span
      title={m.label}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: size,
        height: size,
        borderRadius: "var(--radius-full)",
        background: solid,
        color: "#fff",
        border: "2px solid var(--surface)",
        fontSize: size * 0.55,
        fontWeight: 700,
        lineHeight: 1,
      }}
    >
      {m.glyph}
    </span>
  );
}
