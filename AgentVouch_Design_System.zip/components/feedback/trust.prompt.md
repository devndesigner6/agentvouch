**VerdictChip / VerdictDot / TrustBadge** — the trust-signal family. Trust is the product; these communicate it.

```jsx
<VerdictChip verdict="allow" />          {/* Trusted (emerald) */}
<VerdictChip verdict="review" />         {/* Review (amber) */}
<VerdictDot verdict="avoid" size={16} /> {/* corner badge on a SkillIcon */}

<TrustBadge
  reputation={128} vouches={9}
  backing="2,400" selfBond="500"
  reportStatus={{ label: "Clean", tone: "allow" }}
/>
```

Verdict states: `allow`→Trusted, `review`→Review, `avoid`→Flagged, `unknown`→Unverified. Pass `compact` to `TrustBadge` for a one-line strip. Format USDC amounts before passing them in.
