import * as React from "react";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Leading icon node. */
  icon?: React.ReactNode;
  /** Monospace prefix glyph, e.g. "$" or "@". */
  prefix?: React.ReactNode;
  invalid?: boolean;
  wrapperStyle?: React.CSSProperties;
}

/** Single-line text field — mono, hairline border, coral focus ring. */
export function Input(props: InputProps): JSX.Element;
