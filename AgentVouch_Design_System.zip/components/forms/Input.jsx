import React from "react";

/**
 * Input — single-line text field. Mono type, hairline border, sharp corners,
 * coral focus ring. Supports an optional leading icon and a monospace prefix
 * (e.g. a "$" or "@"). Set `invalid` for the error state.
 */
export function Input({ icon = null, prefix = null, invalid = false, style = {}, wrapperStyle = {}, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const border = invalid ? "var(--verdict-avoid)" : focus ? "var(--accent)" : "var(--border-strong)";
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "8px",
        background: "var(--surface)",
        border: `1px solid ${border}`,
        borderRadius: "var(--radius)",
        padding: "0 12px",
        height: "var(--control-height)",
        boxShadow: focus ? "var(--ring)" : "none",
        transition: "border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
        ...wrapperStyle,
      }}
    >
      {icon && <span style={{ display: "inline-flex", color: "var(--text-faint)" }}>{icon}</span>}
      {prefix && <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-faint)" }}>{prefix}</span>}
      <input
        onFocus={(e) => { setFocus(true); rest.onFocus && rest.onFocus(e); }}
        onBlur={(e) => { setFocus(false); rest.onBlur && rest.onBlur(e); }}
        style={{
          flex: 1,
          minWidth: 0,
          border: "none",
          outline: "none",
          background: "transparent",
          fontFamily: "var(--font-mono)",
          fontSize: "var(--text-sm)",
          color: "var(--text-body)",
          ...style,
        }}
        {...rest}
      />
    </div>
  );
}
