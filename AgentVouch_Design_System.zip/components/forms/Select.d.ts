import * as React from "react";

export type SelectOption = string | { value: string; label: string };

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  options: SelectOption[];
  invalid?: boolean;
}

/** Styled native dropdown matching the Input frame, with a custom chevron. */
export function Select(props: SelectProps): JSX.Element;
