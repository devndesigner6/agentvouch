import React from "react";

/**
 * Select — a styled native dropdown. Matches Input's frame (mono, hairline
 * border, sharp corners, coral focus) with a custom chevron.
 */
export function Select({ options = [], invalid = false, style = {}, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const border = invalid ? "var(--verdict-avoid)" : focus ? "var(--accent)" : "var(--border-strong)";
  return (
    <div style={{ position: "relative", display: "inline-flex", width: "100%" }}>
      <select
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          appearance: "none",
          WebkitAppearance: "none",
          width: "100%",
          height: "var(--control-height)",
          padding: "0 32px 0 12px",
          background: "var(--surface)",
          border: `1px solid ${border}`,
          borderRadius: "var(--radius)",
          fontFamily: "var(--font-mono)",
          fontSize: "var(--text-sm)",
          color: "var(--text-body)",
          outline: "none",
          boxShadow: focus ? "var(--ring)" : "none",
          cursor: "pointer",
          transition: "border-color var(--duration) var(--ease), box-shadow var(--duration) var(--ease)",
          ...style,
        }}
        {...rest}
      >
        {options.map((o) => {
          const value = typeof o === "string" ? o : o.value;
          const label = typeof o === "string" ? o : o.label;
          return (<option key={value} value={value}>{label}</option>);
        })}
      </select>
      <span aria-hidden style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", pointerEvents: "none", color: "var(--text-faint)" }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
      </span>
    </div>
  );
}
