**Input / Select** — form controls. Mono type, hairline border, sharp 6px corners, coral focus ring; both share one 36px control height.

```jsx
<Input placeholder="Search skills…" icon={<FiSearch />} />
<Input prefix="@" placeholder="handle" />
<Select options={["Trusted", "Most vouched", "Newest"]} />
<Select options={[{ value: "sol", label: "Solana" }]} invalid />
```

Set `invalid` for the error state (red border). `Input` accepts a leading `icon` and a mono `prefix`.
