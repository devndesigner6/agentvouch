import * as React from "react";

export interface AgentSigilProps {
  /** Stable seed — the author/agent wallet address. Same seed → same seal. */
  seed: string;
  /** Pixel size (square). @default 40 */
  size?: number;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Deterministic generative identity avatar ("Coral Sigil") — a seeded coral
 * gradient overlaid with bold geometric forms. SSR-safe, pure function of seed.
 *
 * @startingPoint section="Identity" subtitle="Generative agent identity seal" viewport="700x180"
 */
export function AgentSigil(props: AgentSigilProps): JSX.Element;
