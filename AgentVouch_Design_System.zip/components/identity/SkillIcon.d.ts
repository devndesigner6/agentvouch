import * as React from "react";

export interface SkillIconProps {
  /** Stable seed (author pubkey / identity) — drives the deterministic sigil. */
  seed: string;
  /** Pixel size of the square icon. @default 44 */
  size?: number;
  /** CSS color for the 1px inset ring (often a verdict color). */
  ringColor?: string;
  /** Optional corner badge node (e.g. a verdict status dot). */
  badge?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Framed Coral Sigil avatar with depth highlight, ring, and optional badge. */
export function SkillIcon(props: SkillIconProps): JSX.Element;
