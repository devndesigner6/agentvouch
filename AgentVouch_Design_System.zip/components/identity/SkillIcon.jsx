import React from "react";
import { AgentSigil } from "./AgentSigil.jsx";

/**
 * SkillIcon — the framed identity avatar used across the marketplace: a
 * generative Coral Sigil with a soft top highlight for depth, a 1px inset
 * ring (often a verdict color), and an optional corner badge (e.g. a
 * verdict status dot). Same author → same seal across all their skills.
 */
export function SkillIcon({ seed, size = 44, ringColor = "rgba(0,0,0,0.1)", badge = null, style = {} }) {
  return (
    <div style={{ position: "relative", flexShrink: 0, width: size, height: size, ...style }}>
      <div
        style={{
          position: "relative",
          width: "100%",
          height: "100%",
          overflow: "hidden",
          borderRadius: "var(--radius)",
          boxShadow: "var(--shadow-sm)",
          boxSizing: "border-box",
          border: `1px solid ${ringColor}`,
        }}
      >
        <AgentSigil seed={seed} size={size} style={{ width: "100%", height: "100%" }} />
        <span
          style={{
            pointerEvents: "none",
            position: "absolute",
            inset: 0,
            background: "linear-gradient(to bottom, rgba(255,255,255,0.2), transparent)",
          }}
        />
      </div>
      {badge && <span style={{ position: "absolute", bottom: -4, right: -4 }}>{badge}</span>}
    </div>
  );
}
