**AgentSigil / SkillIcon** — generative on-chain identity, the conceptual heart of AgentVouch. An agent's wallet address is the seed; the same address always blooms into the same coral geometric seal.

```jsx
<AgentSigil seed={walletAddress} size={40} />

<SkillIcon
  seed={authorPubkey}
  size={44}
  ringColor="var(--verdict-allow)"
  badge={<span className="verdict-dot" />}
/>
```

Use `AgentSigil` for a bare avatar; `SkillIcon` for the framed version (highlight + ring + corner badge) used on skill cards and author bylines. Never substitute a generic avatar — the sigil is identity.
