# AgentVouch Design System

**agentvouch — trusted tools for AI agents.** AgentVouch is an on-chain reputation layer and skills marketplace for AI agents: a credit bureau for agents instead of people. Before one agent trusts another with a task, access, or payment, it queries AgentVouch for a trust record backed by USDC stake, peer vouches, and dispute history. Live on Solana devnet, powering [agentvouch.xyz](https://agentvouch.xyz).

The product story in one line: `skill.md` is an unsigned binary, and the economics favor attackers — AgentVouch inverts that with stake-backed vouching, slashable disputes, and revenue sharing. The design is inspired by *isnad chains* (hadith authentication): trust depends on who backed whom, and backing must be challengeable.

## Sources

- **GitHub repo:** https://github.com/dirtybits/agentvouch — the production Next.js app lives in `web/` (Tailwind + CSS custom properties in `web/app/globals.css`), the deck theme system in `themes/` (`coral-terminal.md`, `coral-paper.md`, `coral-midnight.md`), pitch decks in `pitch/`, vision docs at root (`README.md`, `VISION.md`, `AGENTS.md`).
- **Live product:** https://agentvouch.xyz (web app) and https://agentvouch.xyz/skill.md (agent-facing install file).

Explore the repo further to do a better job of building designs based on this product — especially `web/app/page.tsx` (landing), `web/app/skills/MarketplaceClient.tsx` (marketplace), `web/components/` (AgentSigil, TrustBadge, SkillPreviewCard), and `themes/coral-terminal.md` (deck theme).

## Products represented

1. **Web app** (`agentvouch.xyz`) — landing page, skills marketplace, skill detail, author profiles, dashboard, docs, blog. Recreated in `ui_kits/web/`.
2. **Pitch / walkthrough decks** — the "Coral Terminal" slide theme (coral title slides → light content → dark code slides). Recreated in `slides/`.
3. **CLI + protocol** — surfaces no UI, but its vocabulary (vouch, slash, bond, dispute, verdict) drives copy everywhere.

---

## CONTENT FUNDAMENTALS

**Voice.** Direct, technical, security-minded — an engineer explaining an exploit, not a marketer selling a dream. Sentences are short and declarative. Claims are backed by mechanisms ("Wrong vouches get slashed"), not adjectives. Occasional dry wit and lobster/claw puns, deployed sparingly and confidently:

> "Buy and sell reputation-backed skills for AI agents. Inspect Author trust scores. **Put your cash where your claw is.**"

> "Reputation infrastructure isn't a nice-to-have for the agent economy. It's the immune system."

**Person.** Second person for the user ("Connect your wallet", "Stake USDC to vouch for agents you trust"). The product speaks as "we" only in vision/blog prose. Agents are referred to in third person ("the agent", "your agent").

**Casing.**
- Eyebrows / section labels: ALL-CAPS tracked mono — `THE PROBLEM`, `AGENT REPUTATION ORACLE`.
- Headings: sentence case ("How it works", "Featured skills"). Product nouns keep their caps (USDC, Solana, AgentVouch).
- Primary CTAs: Title Case ("Browse Skills"); small toggles/utility buttons: sentence case ("For agents", "Copy").
- Capability tags: always lowercase (`payments`, `security-scan`, `solana`).
- Stat labels: uppercase micro mono ("USDC STAKED", "DOWNLOADS").

**Vocabulary.** vouch, stake, bond, slash, dispute, verdict, trust capital, backing, self-bond, reputation oracle, skill.md, on-chain, devnet. Money is always USDC with explicit amounts. Code identifiers stay in backtick mono (`AgentProfile`, `skill.md`).

**Emoji.** Never in product UI. Vision docs use ❌/✓ as list markers only. Verdict glyphs (✓ ! ◇) are unicode characters inside chips, not emoji.

**Numbers.** Real and specific (60/40 split, 286 skills scanned, 4,500 upvotes). Stats render as big serif numerals with small mono labels — never decorate with icons.

---

## VISUAL FOUNDATIONS

**The one-paragraph version:** a warm **coral/lobster accent** (`--lobster #d95a2b`, `--ember #fd522e`) on a **cool gray field** (Tailwind gray scale, `gray-50` background, white cards), with **sea-teal** links/secondary and **gold** tertiary. Monospace (Inconsolata) is the load-bearing UI type; serif (Crimson Text) carries display titles and stat numbers. Sharp 6px corners, 1px hairline borders, dense 4px-grid layouts, and one signature interaction: the **coral hover lift**.

- **Color.** See `tokens/colors.css`. Light mode default; `.dark` scope flips neutrals to ink (`gray-950`) and lifts accents. Trust is a 4-step verdict scale: emerald (Trusted) / amber (Review) / red (Flagged) / gray (Unverified) — each with solid + soft + border variants. Code blocks are dark-on-light (ink panels embedded in light pages).
- **Type.** Inconsolata (mono) is the default body/interface font — not decoration. Crimson Text (serif) for titles, skill names, big stats; Crimson Pro for long-form prose. Weights restrained — the app rarely bolds; serif display is weight 400. Eyebrows: 10px, 700, uppercase, 0.08em tracking, coral.
- **Spacing.** 4px grid, dense. 16px card padding, 12px gaps inside cards, 24px section padding, 48px section rhythm. Containers: 1152px main content, 1280px nav/footer. Sticky 56px navbar with `backdrop-blur`.
- **Backgrounds.** Flat solid colors — `gray-50` page, white cards. **No gradients** on surfaces (gradients appear only inside generated AgentSigils and the logo). Illustrations are used as content images, never page backgrounds.
- **Borders & radii.** 1px hairlines everywhere (`--border`). One true radius: **6px** for cards, buttons, panels, inputs; fully-round only for pills, chips, and verdict dots. A 4px coral **rail** on the left edge of cards reveals on hover.
- **Shadows.** Subtle gray (`--shadow-sm`) at rest. The signature: a warm **coral glow** (`--shadow-coral`) on hovered interactive cards.
- **Hover/press.** Interactive cards: `translateY(-2px)` + coral border + coral shadow + rail reveal, 200ms ease. Buttons deepen their fill (ember → lobster). Links: sea → sea-strong. Text links never underline.
- **Motion.** 120–300ms, standard cubic-bezier ease. Fades and small lifts only — no bounces, no springs, no parallax. One typewriter effect on the landing subtitle.
- **Focus.** 3px soft coral ring (`--ring`), no outline.
- **Selection.** Coral-soft background, coral-deep text.
- **Imagery.** Two families: (1) warm hand-illustrated storybook scenes of lobsters at a harbor marketplace (the brand mascots — warm sunset palette), and (2) a single neon circuit-board network backdrop (cool, dark) for protocol/network contexts. Photography is not used.
- **Cards.** White fill, 1px gray-200 border, 6px radius, `--shadow-sm`, 16px padding. Interactive → coral lift. Optional verdict-colored left rail.

---

## ICONOGRAPHY

- **Icon system: Feather icons** via `react-icons/fi` (`FiShield`, `FiUsers`, `FiDownload`, `FiZap`, `FiTerminal`, `FiArrowRight`, …) — 2px stroke, round caps, no fill. Brand glyphs from `react-icons` too: `FaDiscord`, `SiX`, `FiGithub`.
- In this design system, components embed minimal inline Feather-style SVGs (stroke 2, currentColor) to stay dependency-free. For new work, link **Lucide** from CDN (`https://unpkg.com/lucide@latest`) — it's the maintained superset of Feather with identical stroke style. **Flagged substitution:** Feather → Lucide for CDN use.
- **No icon font.** No PNG icons. Unicode glyphs (✓ ! ◇ →) are used inside chips and links as text.
- Icons are always `currentColor`, usually coral when decorative, 14–16px inline with text.
- **Identity art is generative, not iconic:** the `AgentSigil` component renders a deterministic coral-palette seal from a wallet address. Same seed → same sigil. Never use generic avatars.
- Assets in `assets/`: `agentvouch-logo.svg` (lobster-in-shield, ember gradient), `agentvouch-mark.png` (raster mark), `usdc.svg` (currency icon), lobster illustrations (`lobster-marketplace.png`, `lobster-reading-skill.png`, `lobster-sparky.png`, `hijacking-trust-clawhub.png`, `trust-signals.png`), `network-backdrop.png` (neon network).

---

## FONTS

All three families are genuine Google Fonts loaded from the Google Fonts CDN in `tokens/fonts.css` (matching the production app's `next/font/google` setup — no substitution needed):

- **Inconsolata** — mono; UI, body, labels, code
- **Crimson Text** — display serif; titles, stats
- **Crimson Pro** — reading serif; prose

The deck theme (`themes/coral-terminal.md`) specifies Arial Black headers + Calibri body for PowerPoint; the HTML slide kit here substitutes **Arial Black/system** and **Calibri → system sans fallback**, keeping Inconsolata as the signature mono. Provide font files if pixel-parity with the .pptx decks matters.

---

## INDEX

| Path | What |
|---|---|
| `styles.css` | Global entry point — `@import`s every token file. Consumers link this one file. |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `base.css` |
| `assets/` | Logo, mark, USDC icon, lobster illustrations, network backdrop |
| `guidelines/` | Foundation specimen cards (Design System tab) |
| `components/core/` | `Button`, `Badge`, `Tag`, `Eyebrow` |
| `components/forms/` | `Input`, `Select` |
| `components/data/` | `Card`, `SkillCard`, `StatBlock` |
| `components/feedback/` | `VerdictChip`, `VerdictDot`, `TrustBadge` |
| `components/identity/` | `AgentSigil`, `SkillIcon` |
| `ui_kits/web/` | Interactive recreation of agentvouch.xyz — landing, marketplace, skill detail |
| `slides/` | Coral Terminal slide kit — title, content, code, stat, closing slides |
| `SKILL.md` | Agent-skill entry point for using this design system elsewhere |

Component usage: every component has a `.d.ts` props contract and a `.prompt.md` usage note in its directory. Mount via the compiled bundle: `window.AgentVouchDesignSystem_7f5188`.
