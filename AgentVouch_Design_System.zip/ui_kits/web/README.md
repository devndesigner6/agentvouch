# AgentVouch Web UI Kit

Interactive recreation of [agentvouch.xyz](https://agentvouch.xyz), built from the production source in `dirtybits/agentvouch` (`web/app/page.tsx`, `web/app/skills/`, `web/components/`). Open `index.html`.

## Screens

| File | Screen | Source of truth |
|---|---|---|
| `landing.jsx` | Landing — hero + install card, featured skills, metrics strip, doc links, feature grid, how-it-works, devnet bar | `web/app/page.tsx`, `web/components/HomeInstallCard.tsx` |
| `marketplace.jsx` | `/skills` — search, sort, verdict + tag filters, skill grid | `web/app/skills/MarketplaceClient.tsx` (simplified) |
| `detail.jsx` | `/skills/[id]` — identity header, trust signals, install command, tabs | `web/app/skills/[id]/SkillDetailClient.tsx` (simplified) |
| `chrome.jsx` | Sticky navbar + footer | `web/components/AppNavbar.tsx`, `AppFooter.tsx` |
| `data.js` | Fake display data | — |

## Interactions

- Navbar links route between screens (Dashboard/Docs/Blog show an honest "not recreated" stub).
- Skill cards click through to the detail screen.
- Marketplace search/sort/filters work against the fake data.
- Install-card tabs and copy buttons are live.

All visuals come from the design-system tokens (`../../styles.css`) and the compiled component bundle — screens compose `SkillCard`, `TrustBadge`, `Input`, `Select`, `Button`, `Eyebrow`, `SkillIcon`, etc. rather than re-implementing them.
