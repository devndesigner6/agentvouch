// AgentVouch UI kit — app chrome: sticky navbar + footer.
// Recreated from web/components/AppNavbar.tsx and AppFooter.tsx.
const chromeIco = { width: 16, height: 16, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
const ChromeGithub = () => (<svg {...chromeIco}><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" /></svg>);
const ChromeMoon = () => (<svg {...chromeIco}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /></svg>);

function AppNavbar({ active, onNav }) {
  const links = [
    { id: "market", label: "Marketplace" },
    { id: "dashboard", label: "Dashboard" },
    { id: "docs", label: "Docs" },
    { id: "blog", label: "Blog" },
  ];
  return (
    <nav style={{ position: "sticky", top: 0, zIndex: 50, borderBottom: "1px solid var(--border)", background: "rgba(249,250,251,0.8)", backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)" }}>
      <div style={{ maxWidth: "var(--container-xl)", margin: "0 auto", padding: "0 24px", height: "var(--navbar-height)", display: "flex", alignItems: "center", gap: "12px" }}>
        <a onClick={() => onNav("landing")} style={{ display: "flex", alignItems: "center", gap: "8px", fontFamily: "var(--font-display)", fontSize: "16px", color: "var(--foreground)", cursor: "pointer", flexShrink: 0 }}>
          <img src="../../assets/agentvouch-mark.png" alt="" width="24" height="24" style={{ borderRadius: "2px", display: "block" }} />
          AgentVouch
        </a>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: "4px", minWidth: 0 }}>
          {links.map((l) => (
            <a key={l.id} onClick={() => onNav(l.id)} aria-current={active === l.id ? "page" : undefined}
              style={{ fontFamily: "var(--font-display)", fontSize: "15px", padding: "4px 8px", whiteSpace: "nowrap", cursor: "pointer", color: active === l.id ? "var(--foreground)" : "var(--text-muted)", transition: "color var(--duration) var(--ease)" }}>
              {l.label}
            </a>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", flexShrink: 0 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "6px", padding: "6px 12px", border: "1px solid var(--border-strong)", borderRadius: "var(--radius)", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-muted)", cursor: "pointer" }}><ChromeGithub /> Sign in</span>
          <span style={{ display: "inline-flex", alignItems: "center", padding: "6px 14px", background: "var(--accent-strong)", color: "#fff", borderRadius: "var(--radius)", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", cursor: "pointer" }}>Select Wallet</span>
          <span style={{ display: "inline-flex", padding: "6px", color: "var(--text-muted)", cursor: "pointer" }}><ChromeMoon /></span>
        </div>
      </div>
    </nav>
  );
}

function AppFooter() {
  return (
    <footer style={{ borderTop: "1px solid var(--border)", background: "var(--background)" }}>
      <div style={{ maxWidth: "var(--container-xl)", margin: "0 auto", padding: "24px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>
        <span style={{ fontFamily: "var(--font-display)", color: "var(--foreground)" }}>AgentVouch</span>
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "6px", cursor: "pointer" }}><ChromeGithub /> GitHub</span>
          <span style={{ cursor: "pointer" }}>X</span>
          <span style={{ cursor: "pointer" }}>Discord</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { AppNavbar, AppFooter });
