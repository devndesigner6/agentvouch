// AgentVouch UI kit — skill detail screen. Recreation of /skills/[id]
// (web/app/skills/[id]/SkillDetailClient.tsx, simplified: header with
// identity + verdict, trust signal panel, install command, vouch action).
function SkillDetailPage({ skill, onBack }) {
  const DS = window.AgentVouchDesignSystem_7f5188;
  const { SkillIcon, VerdictChip, VerdictDot, Tag, Button, TrustBadge, Eyebrow } = DS;
  const [copied, setCopied] = React.useState(false);
  const [tab, setTab] = React.useState("readme");
  const s = skill;
  const ringColor = { allow: "var(--verdict-allow)", review: "var(--verdict-review)", avoid: "var(--verdict-avoid)", unknown: "var(--verdict-unknown)" }[s.verdict];
  const installCmd = `curl -s https://agentvouch.xyz/api/skills/${s.id}/raw`;

  return (
    <main style={{ background: "var(--background)", minHeight: "100%", padding: "32px 24px 48px" }}>
      <div style={{ maxWidth: "var(--container-md)", margin: "0 auto" }}>
        <a onClick={onBack} style={{ display: "inline-block", marginBottom: "20px", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--link)", cursor: "pointer" }}>← Back to marketplace</a>

        {/* header */}
        <div style={{ display: "flex", alignItems: "flex-start", gap: "16px", marginBottom: "20px" }}>
          <SkillIcon seed={s.authorSeed} size={64} ringColor={ringColor} badge={<VerdictDot verdict={s.verdict} size={18} />} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
              <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", margin: 0 }}>{s.name}</h1>
              <VerdictChip verdict={s.verdict} />
            </div>
            <div style={{ marginTop: "4px", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-muted)" }}>
              by <span style={{ color: "var(--sea)" }}>{s.author}</span> · v{s.version} · {s.downloads} downloads
            </div>
            <div style={{ marginTop: "8px", display: "flex", gap: "6px", flexWrap: "wrap" }}>
              {s.tags.map((t) => (<Tag key={t}>{t}</Tag>))}
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px", alignItems: "stretch", flexShrink: 0 }}>
            <Button>{s.price ? `Buy · ${s.price} USDC` : "Install Free"}</Button>
            <Button variant="secondary">Vouch 50 USDC</Button>
          </div>
        </div>

        <p style={{ margin: "0 0 20px", fontFamily: "var(--font-article)", fontSize: "var(--text-md)", lineHeight: 1.6, color: "var(--text-body)" }}>{s.description}</p>

        {/* trust signals */}
        <div style={{ marginBottom: "20px" }}>
          <div style={{ marginBottom: "10px" }}><Eyebrow>AUTHOR TRUST SIGNALS</Eyebrow></div>
          <TrustBadge reputation={s.reputation} vouches={s.vouches} backing={s.backing} selfBond={s.selfBond} reportStatus={s.reportStatus} />
        </div>

        {/* install */}
        <div style={{ background: "var(--surface-code)", borderRadius: "var(--radius)", marginBottom: "20px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 14px", borderBottom: "1px solid var(--gray-800)" }}>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-2xs)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--coral)" }}>Install</span>
            <button onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }} style={{ border: "none", background: "none", cursor: "pointer", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: copied ? "#34d399" : "var(--gray-400)" }}>{copied ? "✓ Copied" : "Copy"}</button>
          </div>
          <pre style={{ margin: 0, padding: "14px", overflowX: "auto", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--gray-300)" }}><code>$ {installCmd}</code></pre>
        </div>

        {/* tabs */}
        <div style={{ display: "flex", gap: "2px", borderBottom: "1px solid var(--border)", marginBottom: "16px" }}>
          {[{ id: "readme", label: "README" }, { id: "files", label: "Files" }, { id: "versions", label: "Versions" }, { id: "vouches", label: `Vouches (${s.vouches})` }].map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ border: "none", background: "none", cursor: "pointer", padding: "8px 14px", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: tab === t.id ? "var(--accent)" : "var(--text-muted)", borderBottom: tab === t.id ? "2px solid var(--accent)" : "2px solid transparent", marginBottom: "-1px" }}>{t.label}</button>
          ))}
        </div>
        <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "20px", minHeight: "120px" }}>
          {tab === "readme" && (
            <div style={{ fontFamily: "var(--font-article)", fontSize: "var(--text-md)", lineHeight: 1.65, color: "var(--text-body)" }}>
              <h3 style={{ fontFamily: "var(--font-display)", margin: "0 0 8px" }}>{s.name}</h3>
              {s.description} Trust signals on this page are read live from the on-chain record — reputation, stake-backed vouches, and dispute history for <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.9em" }}>{s.author}</span>.
            </div>
          )}
          {tab !== "readme" && (
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-faint)", textAlign: "center", padding: "24px 0" }}>
              {tab === "files" && "skill.md · 4.2 KB — single-file integration"}
              {tab === "versions" && `v${s.version} (current) · published on-chain`}
              {tab === "vouches" && (s.vouches > 0 ? `${s.vouches} stake-backed vouches, ${s.backing} USDC total backing` : "No vouches yet. Be the first to put cash behind this claw.")}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { SkillDetailPage });
