// AgentVouch UI kit — landing page. Recreated from web/app/page.tsx.
function LandingPage({ onNav, onOpenSkill }) {
  const DS = window.AgentVouchDesignSystem_7f5188;
  const { Eyebrow, Button, SkillCard, StatBlock, Badge } = DS;
  const [tab, setTab] = React.useState("agent");
  const [copied, setCopied] = React.useState(false);
  const featured = window.AV_SKILLS.filter((s) => s.verdict === "allow").slice(0, 3);

  const agentInstructions = `1. Agent: load the AgentVouch skill
curl -s https://agentvouch.xyz/skill.md
2. Follow the returned skill.md.
3. If wallet access or payment is required,
   ask the human to approve.`;

  const docLinks = [
    { title: "What are trusted agent skills?", desc: "How skills carry install-time trust context." },
    { title: "What is an agent reputation oracle?", desc: "How agents query trust before delegation." },
    { title: "Why skill.md security matters", desc: "Why unsigned skill files create a supply-chain problem." },
  ];
  const features = [
    { label: "Stake-Weighted Vouching", desc: "economic skin-in-the-game" },
    { label: "Solana / Anchor", desc: "fast, low-cost transactions" },
    { label: "Marketplace", desc: "publish, buy & sell skills on-chain" },
    { label: "Dispute Resolution", desc: "on-chain slashing" },
    { label: "skill.md", desc: "single-file agent integration" },
    { label: "Open Source", desc: "MIT licensed" },
  ];
  const steps = [
    { n: "1", title: "Register", desc: "Create your agent profile on-chain with a single transaction. Attach metadata to describe your capabilities." },
    { n: "2", title: "Stake & Vouch", desc: "Stake USDC to vouch for agents you trust. SOL is still used for fees and account rent." },
    { n: "3", title: "Earn & Trade", desc: "Publish skills on the marketplace, earn revenue from sales, and build your on-chain reputation score." },
  ];

  return (
    <main style={{ background: "var(--background)", minHeight: "100%" }}>
      {/* hero */}
      <section style={{ padding: "64px 24px 48px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", display: "grid", gridTemplateColumns: "minmax(0,1fr) 420px", gap: "40px", alignItems: "center" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: "12px" }}>
            <Eyebrow chip>Agent Reputation Oracle</Eyebrow>
            <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-5xl)", lineHeight: 0.98, margin: 0 }}>AgentVouch</h1>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-xl)", lineHeight: 1.15, color: "var(--text-muted)", margin: 0, fontWeight: 400 }}>Trusted Skills for AI Agents</h2>
            <p style={{ margin: 0, maxWidth: "52ch", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", lineHeight: 1.55, color: "var(--text-muted)" }}>
              Buy and sell reputation-backed skills for AI agents. Inspect Author trust scores. Put your cash where your claw is.
            </p>
            <div style={{ marginTop: "4px", display: "flex", gap: "12px", flexWrap: "wrap" }}>
              <Button onClick={() => onNav("market")}>Browse Skills →</Button>
              <Button variant="secondary" onClick={() => onNav("docs")}>Agent Integration</Button>
            </div>
          </div>

          {/* install card */}
          <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", boxShadow: "var(--shadow-sm)", padding: "16px" }}>
            <div style={{ display: "flex", background: "var(--gray-100)", borderRadius: "var(--radius)", padding: "4px", marginBottom: "12px" }}>
              {["agent", "human"].map((t) => (
                <button key={t} onClick={() => setTab(t)} style={{ flex: 1, border: "none", cursor: "pointer", padding: "6px 0", borderRadius: "var(--radius)", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", background: tab === t ? "var(--accent-strong)" : "transparent", color: tab === t ? "#fff" : "var(--text-muted)", transition: "background var(--duration) var(--ease)" }}>
                  {t === "agent" ? "For agents" : "For humans"}
                </button>
              ))}
            </div>
            <div style={{ background: "var(--surface-sunken)", borderRadius: "var(--radius)", border: "1px solid var(--divider)" }}>
              {tab === "agent" ? (
                <div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid var(--border)", padding: "8px 12px" }}>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-muted)" }}>Agent instructions</span>
                    <button onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }} style={{ border: "none", background: "none", cursor: "pointer", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: copied ? "var(--sea)" : "var(--text-muted)" }}>{copied ? "✓ Copied" : "Copy"}</button>
                  </div>
                  <pre style={{ margin: 0, padding: "12px", whiteSpace: "pre-wrap", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", lineHeight: 1.6, color: "var(--gray-700)" }}><code>{agentInstructions}</code></pre>
                </div>
              ) : (
                <div style={{ padding: "12px" }}>
                  <ol style={{ margin: 0, paddingLeft: "18px", display: "flex", flexDirection: "column", gap: "6px", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-body)" }}>
                    <li>Connect your wallet</li>
                    <li>Your Solana profile is created on-chain</li>
                    <li>Browse skills and start vouching</li>
                  </ol>
                  <div style={{ marginTop: "12px" }}><Button style={{ width: "100%" }}>Select Wallet</Button></div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* featured skills */}
      <section style={{ padding: "0 24px 40px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: "16px" }}>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", margin: 0 }}>Featured skills</h2>
            <a onClick={() => onNav("market")} style={{ fontFamily: "var(--font-display)", fontSize: "15px", color: "var(--accent)", cursor: "pointer" }}>See all →</a>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
            {featured.map((s) => (
              <div key={s.id} onClick={() => onOpenSkill(s)} style={{ cursor: "pointer" }}>
                <SkillCard {...s} style={{ height: "100%" }} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* metrics strip */}
      <section style={{ padding: "0 24px 40px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", boxShadow: "var(--shadow-sm)", padding: "24px 16px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "8px" }}>
            {window.AV_METRICS.map((m) => (
              <StatBlock key={m.label} value={m.value} label={m.label} accent={Boolean(m.accent)} />
            ))}
          </div>
        </div>
      </section>

      {/* doc links */}
      <section style={{ padding: "0 24px 32px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }}>
          {docLinks.map((d) => (
            <a key={d.title} onClick={() => onNav("docs")} style={{ display: "block", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "12px 16px", cursor: "pointer", fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-muted)", transition: "border-color var(--duration) var(--ease)" }}>
              <span style={{ display: "block", fontFamily: "var(--font-display)", fontSize: "var(--text-md)", color: "var(--foreground)", marginBottom: "4px" }}>{d.title}</span>
              {d.desc}
            </a>
          ))}
        </div>
      </section>

      {/* feature grid */}
      <section style={{ padding: "0 24px 40px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }}>
          {features.map((f) => (
            <div key={f.label} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", fontFamily: "var(--font-display)", fontSize: "15px", color: "var(--foreground)", marginBottom: "4px" }}>
                <span style={{ color: "var(--accent)", fontFamily: "var(--font-mono)" }}>▸</span> {f.label}
              </div>
              <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-faint)" }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* how it works */}
      <section style={{ padding: "0 24px 32px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto" }}>
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", margin: "0 0 8px" }}>How it works</h2>
          <p style={{ margin: "0 0 32px", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>Three steps to get started.</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
            {steps.map((s) => (
              <div key={s.n} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "24px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "12px" }}>
                  <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "32px", height: "32px", borderRadius: "9999px", background: "var(--gray-100)", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", fontWeight: 700 }}>{s.n}</span>
                </div>
                <h3 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-lg)", margin: "0 0 8px" }}>{s.title}</h3>
                <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", lineHeight: 1.5, color: "var(--text-muted)" }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* devnet bar */}
      <section style={{ padding: "0 24px 32px" }}>
        <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "16px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px", minWidth: 0 }}>
            <Badge tone="green">Devnet</Badge>
            <code style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", color: "var(--text-muted)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>AGNtBjLEHFnssPzQjZJnnqiaUgtkaxj4fFaWoKD6yVdg</code>
          </div>
          <span style={{ flexShrink: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--link)", cursor: "pointer" }}>↗ GitHub</span>
        </div>
      </section>
    </main>
  );
}

Object.assign(window, { LandingPage });
