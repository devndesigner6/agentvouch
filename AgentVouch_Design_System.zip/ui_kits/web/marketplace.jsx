// AgentVouch UI kit — marketplace screen. Recreation of /skills
// (web/app/skills/MarketplaceClient.tsx, simplified: search, sort,
// verdict filter, tag filter, skill grid).
function MarketplacePage({ onOpenSkill }) {
  const DS = window.AgentVouchDesignSystem_7f5188;
  const { Input, Select, SkillCard, Tag, Button, VerdictChip } = DS;
  const [query, setQuery] = React.useState("");
  const [verdict, setVerdict] = React.useState("all");
  const [tag, setTag] = React.useState(null);

  const allTags = [...new Set(window.AV_SKILLS.flatMap((s) => s.tags))];
  const skills = window.AV_SKILLS.filter((s) => {
    if (verdict !== "all" && s.verdict !== verdict) return false;
    if (tag && !s.tags.includes(tag)) return false;
    if (query && !(s.name + s.author + s.description).toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });

  const SearchIcon = () => (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>);

  return (
    <main style={{ background: "var(--background)", minHeight: "100%", padding: "32px 24px 48px" }}>
      <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "16px", marginBottom: "20px" }}>
          <div>
            <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", margin: "0 0 4px" }}>Skill Marketplace</h1>
            <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{skills.length} skills · trust signals on every card</p>
          </div>
          <Button>+ Publish Skill</Button>
        </div>

        {/* filter bar */}
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 200px 180px", gap: "10px", marginBottom: "12px" }}>
          <Input icon={<SearchIcon />} placeholder="Search skills, authors…" value={query} onChange={(e) => setQuery(e.target.value)} />
          <Select options={[{ value: "trusted", label: "Most trusted" }, { value: "downloads", label: "Most downloads" }, { value: "newest", label: "Newest" }]} />
          <Select value={verdict} onChange={(e) => setVerdict(e.target.value)} options={[{ value: "all", label: "All verdicts" }, { value: "allow", label: "Trusted" }, { value: "review", label: "Review" }, { value: "avoid", label: "Flagged" }, { value: "unknown", label: "Unverified" }]} />
        </div>

        {/* tag rail */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "20px" }}>
          {allTags.map((t) => (
            <Tag key={t} onClick={() => setTag(tag === t ? null : t)} style={tag === t ? { background: "var(--accent)", color: "#fff", borderColor: "var(--accent)" } : {}}>{t}</Tag>
          ))}
        </div>

        {/* grid */}
        {skills.length > 0 ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
            {skills.map((s) => (
              <div key={s.id} onClick={() => onOpenSkill(s)} style={{ cursor: "pointer" }}>
                <SkillCard {...s} style={{ height: "100%" }} />
              </div>
            ))}
          </div>
        ) : (
          <div style={{ border: "1px dashed var(--border-strong)", borderRadius: "var(--radius)", padding: "48px", textAlign: "center" }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-lg)", marginBottom: "6px" }}>No skills match</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>Clear a filter or two and try again.</div>
          </div>
        )}
      </div>
    </main>
  );
}

Object.assign(window, { MarketplacePage });
